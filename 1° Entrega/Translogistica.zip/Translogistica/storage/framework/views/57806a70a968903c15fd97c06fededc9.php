<?php $__env->startSection('title', 'Mis cargas | Translogística'); ?>

<?php $__env->startSection('content'); ?>
    <div class="min-vh-100 bg-light">
        <?php if (isset($component)) { $__componentOriginal19fff246197017a876e8761e85e28801 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19fff246197017a876e8761e85e28801 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cliente-navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cliente-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19fff246197017a876e8761e85e28801)): ?>
<?php $attributes = $__attributesOriginal19fff246197017a876e8761e85e28801; ?>
<?php unset($__attributesOriginal19fff246197017a876e8761e85e28801); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19fff246197017a876e8761e85e28801)): ?>
<?php $component = $__componentOriginal19fff246197017a876e8761e85e28801; ?>
<?php unset($__componentOriginal19fff246197017a876e8761e85e28801); ?>
<?php endif; ?>

        <main class="container py-5">
            <header class="mb-4">
                <h1 class="fw-bold mb-2">
                    Mis cargas
                </h1>

                <p class="text-secondary mb-0">
                    Consultá las operaciones asociadas a tu cuenta.
                </p>
            </header>

            <section class="card border-0 shadow-sm mb-4">
                <div class="card-body">
                    <form method="GET" action="<?php echo e(route('cliente.cargas.buscar')); ?>">
                        <div class="row g-3 align-items-end">
                            <div class="col-12 col-md-8">
                                <label for="buscar-dua" class="form-label fw-semibold">
                                    Buscar por número de DUA
                                </label>

                                <input type="text" id="buscar-dua" name="dua" value="<?php echo e(old('dua')); ?>"
                                    class="form-control
                                        <?php $__errorArgs = ['dua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Ejemplo: 123456" inputmode="numeric" maxlength="6" pattern="[0-9]{1,6}">

                                <?php $__errorArgs = ['dua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-12 col-md-4">
                                <button type="submit" class="btn btn-dark w-100">
                                    <i class="bi bi-search me-2"></i>
                                    Buscar
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </section>

            <section class="card border-0 shadow-sm">
                <div class="card-header bg-white py-3">
                    <h2 class="h5 fw-bold mb-0">
                        Cargas registradas
                    </h2>
                </div>

                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-dark">
                            <tr>
                                <th scope="col">CRT</th>
                                <th scope="col">DUA</th>
                                <th scope="col">Operación</th>
                                <th scope="col">Estado</th>

                                <th scope="col" class="text-end">
                                    Acción
                                </th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $cargas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php
                                    $nombreOperacion = match ($carga->tipo_operacion) {
                                        'importacion' => 'Importación',
                                        'exportacion' => 'Exportación',
                                        default => 'Sin especificar',
                                    };

                                    $nombreEstado = match ($carga->estado) {
                                        'iniciada' => 'Iniciada',
                                        'en_curso' => 'En curso',
                                        'en_frontera' => 'En frontera',
                                        'entregada' => 'Entregada',
                                        default => 'Sin especificar',
                                    };

                                    $colorEstado = match ($carga->estado) {
                                        'iniciada' => 'secondary',
                                        'en_curso' => 'primary',
                                        'en_frontera' => 'warning',
                                        'entregada' => 'success',
                                        default => 'secondary',
                                    };
                                ?>

                                <tr>
                                    <td>
                                        <?php echo e($carga->num_crt ?? 'Sin especificar'); ?>

                                    </td>

                                    <td>
                                        <?php echo e($carga->dua ?? 'Sin especificar'); ?>

                                    </td>

                                    <td>
                                        <?php echo e($nombreOperacion); ?>

                                    </td>

                                    <td>
                                        <span class="badge text-bg-<?php echo e($colorEstado); ?>">
                                            <?php echo e($nombreEstado); ?>

                                        </span>
                                    </td>

                                    <td class="text-end">
                                        <a href="<?php echo e(route('cliente.cargas.show', $carga->id)); ?>"
                                            class="btn btn-sm btn-outline-dark">
                                            Ver estado
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="text-center text-secondary py-5">
                                        No hay cargas registradas para
                                        tu cuenta.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="card-footer bg-white text-secondary">
                    Solo se muestran las cargas asociadas a tu cuenta.
                </div>
            </section>
        </main>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Fefog\Desktop\Proyecto-Final\Translogistica\resources\views\cliente\cargas\index.blade.php ENDPATH**/ ?>