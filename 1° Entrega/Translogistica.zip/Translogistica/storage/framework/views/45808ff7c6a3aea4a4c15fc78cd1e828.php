<?php $__env->startSection('title', 'Nueva ficha | Translogística'); ?>
<?php $__env->startSection('content'); ?>
<div class="min-vh-100 bg-light">
    <?php if (isset($component)) { $__componentOriginalbe062454937ca58204f074f7f20cd3ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbe062454937ca58204f074f7f20cd3ac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.panel-navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('panel-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbe062454937ca58204f074f7f20cd3ac)): ?>
<?php $attributes = $__attributesOriginalbe062454937ca58204f074f7f20cd3ac; ?>
<?php unset($__attributesOriginalbe062454937ca58204f074f7f20cd3ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbe062454937ca58204f074f7f20cd3ac)): ?>
<?php $component = $__componentOriginalbe062454937ca58204f074f7f20cd3ac; ?>
<?php unset($__componentOriginalbe062454937ca58204f074f7f20cd3ac); ?>
<?php endif; ?>
    <main class="container py-5">
        <div class="mb-4">
            <a href="<?php echo e(route('panel.fichas.index')); ?>" class="text-decoration-none">
                <i class="bi bi-arrow-left me-1"></i>
                Volver a fichas
            </a>
        </div>
        <div class="mb-4">
            <h1 class="fw-bold mb-1">
                Nueva ficha
            </h1>
            <p class="text-secondary mb-0">
                Registro de una nueva operación de transporte.
            </p>
        </div>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
            <p class="fw-bold mb-2">
                Revisá los datos ingresados:
            </p>
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <form id="form-nueva-ficha" method="POST" action="<?php echo e(route('panel.fichas.store')); ?>"
            data-has-old-input="<?php echo e(session()->hasOldInput() ? '1' : '0'); ?>">
            <?php echo csrf_field(); ?>
            <section class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-dark text-white py-3">
                    <h2 class="h5 mb-0">
                        Referencia
                    </h2>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-12 col-md-6 col-lg-3">
                            <label for="tipo_operacion" class="form-label fw-semibold">
                                Tipo de operación
                            </label>
                            <select id="tipo_operacion" name="tipo_operacion"
                                class="form-select <?php $__errorArgs = ['tipo_operacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                <option value="">
                                    Seleccionar
                                </option>
                                <option value="importacion" <?php if(old('tipo_operacion')==='importacion' ): echo 'selected'; endif; ?>>
                                    Importación
                                </option>
                                <option value="exportacion" <?php if(old('tipo_operacion')==='exportacion' ): echo 'selected'; endif; ?>>
                                    Exportación
                                </option>
                            </select>
                            <?php $__errorArgs = ['tipo_operacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 col-md-6 col-lg-3">
                            <label for="numero_ficha" class="form-label fw-semibold">
                                Número de ficha
                            </label>
                            <input type="text" id="numero_ficha" name="numero_ficha"
                                value="<?php echo e(old('numero_ficha')); ?>"
                                class="form-control <?php $__errorArgs = ['numero_ficha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" maxlength="50"
                                placeholder="Ej.: 7381">
                            <?php $__errorArgs = ['numero_ficha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 col-md-6 col-lg-3">
                            <label for="transportista" class="form-label fw-semibold">
                                Transportista
                            </label>
                            <select id="transportista" name="transportista"
                                class="form-select <?php $__errorArgs = ['transportista'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <option value="">
                                    Sin transportista asignado
                                </option>
                                <?php $__currentLoopData = $transportistas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transportista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($transportista->id); ?>" <?php if((string) old('transportista')===(string) $transportista->id): echo 'selected'; endif; ?>>
                                    <?php echo e($transportista->nombre); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['transportista'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 col-md-6 col-lg-3">
                            <label for="num_crt" class="form-label fw-semibold">
                                Número de CRT
                            </label>
                            <input type="text" id="num_crt" name="num_crt" value="<?php echo e(old('num_crt')); ?>"
                                class="form-control <?php $__errorArgs = ['num_crt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" maxlength="255"
                                placeholder="Ej.: BR-000123456">
                            <?php $__errorArgs = ['num_crt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </section>
            <section class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-dark text-white py-3">
                    <h2 class="h5 mb-0">Cliente nacional</h2>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-12">
                            <label for="cliente_id" class="form-label fw-semibold">Cliente nacional (Uruguay)</label>
                            <select id="cliente_id" name="cliente_id" class="form-select <?php $__errorArgs = ['cliente_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                <option value="">Seleccionar cliente nacional</option>
                                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($cliente->origen === 'local'): ?>
                                <option value="<?php echo e($cliente->id); ?>"
                                    data-nombre="<?php echo e($cliente->nombre); ?>"
                                    data-contacto="<?php echo e($cliente->contacto_nombre); ?>"
                                    data-telefono="<?php echo e($cliente->telefono); ?>"
                                    data-ruc-rut="<?php echo e($cliente->ruc_rut); ?>"
                                    <?php if((string) old('cliente_id')===(string) $cliente->id): echo 'selected'; endif; ?>>
                                    <?php echo e($cliente->nombre); ?>

                                </option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['cliente_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 col-lg-6">
                            <label for="cliente_nombre" class="form-label fw-semibold">Nombre del cliente en la operación</label>
                            <input type="text" id="cliente_nombre" name="cliente_nombre" value="<?php echo e(old('cliente_nombre')); ?>" class="form-control" maxlength="255">
                            <div class="form-text">Si queda vacío, se utilizará el nombre del cliente asociado.</div>
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="cliente_contacto" class="form-label fw-semibold">Contacto</label>
                            <input type="text" id="cliente_contacto" name="cliente_contacto" value="<?php echo e(old('cliente_contacto')); ?>" class="form-control" maxlength="255">
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="cliente_ruc" class="form-label fw-semibold">RUC/RUT</label>
                            <input type="text" id="cliente_ruc" name="cliente_ruc" value="<?php echo e(old('cliente_ruc')); ?>" class="form-control" maxlength="50">
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="cliente_telefono" class="form-label fw-semibold">Teléfono</label>
                            <input type="tel" id="cliente_telefono" name="cliente_telefono" value="<?php echo e(old('cliente_telefono')); ?>" class="form-control" maxlength="50">
                        </div>
                    </div>
                </div>
            </section>
            <section class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-dark text-white py-3">
                    <h2 class="h5 mb-0">Cliente internacional</h2>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-12">
                            <label for="cliente_internacional_id" class="form-label fw-semibold" id="etiqueta-cliente-internacional">Cliente internacional (Brasil o Argentina)</label>
                            <select id="cliente_internacional_id" name="cliente_internacional_id" class="form-select <?php $__errorArgs = ['cliente_internacional_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <option value="">Sin cliente internacional asignado</option>
                                <?php $__currentLoopData = $clientesInternacionales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clienteInternacional): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($clienteInternacional->id); ?>"
                                    data-nombre="<?php echo e($clienteInternacional->nombre); ?>"
                                    data-contacto="<?php echo e($clienteInternacional->contacto_nombre); ?>"
                                    data-email="<?php echo e($clienteInternacional->contacto_email); ?>"
                                    data-telefono="<?php echo e($clienteInternacional->telefono); ?>"
                                    data-despachante="<?php echo e($clienteInternacional->despachante); ?>"
                                    <?php if((string) old('cliente_internacional_id')===(string) $clienteInternacional->id): echo 'selected'; endif; ?>>
                                    <?php echo e($clienteInternacional->nombre); ?> (<?php echo e($clienteInternacional->origen === 'brasil' ? 'Brasil' : 'Argentina'); ?>)
                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['cliente_internacional_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="rol_cliente_internacional" class="form-label fw-semibold">Rol en la operación</label>
                            <input type="text" id="rol_cliente_internacional" class="form-control bg-light" value="Sin definir" readonly aria-readonly="true">
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="exportador_nombre" class="form-label fw-semibold" id="etiqueta-nombre-internacional">Nombre del <span data-rol-internacional>Exportador</span></label>
                            <input type="text" id="exportador_nombre" name="exportador_nombre" value="<?php echo e(old('exportador_nombre')); ?>" class="form-control" maxlength="255">
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="exportador_contacto" class="form-label fw-semibold">Contacto</label>
                            <input type="text" id="exportador_contacto" name="exportador_contacto" value="<?php echo e(old('exportador_contacto')); ?>" class="form-control" maxlength="255">
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="exportador_email" class="form-label fw-semibold">Email del contacto</label>
                            <input type="email" id="exportador_email" name="exportador_email" value="<?php echo e(old('exportador_email')); ?>" class="form-control <?php $__errorArgs = ['exportador_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" maxlength="255">
                            <?php $__errorArgs = ['exportador_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="exportador_telefono" class="form-label fw-semibold">Teléfono</label>
                            <input type="tel" id="exportador_telefono" name="exportador_telefono" value="<?php echo e(old('exportador_telefono')); ?>" class="form-control" maxlength="50">
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="despachante_exportador" class="form-label fw-semibold">Despachante</label>
                            <input type="text" id="despachante_exportador" name="despachante_exportador" value="<?php echo e(old('despachante_exportador')); ?>" class="form-control" maxlength="255">
                        </div>
                        <div class="col-12">
                            <label for="mercaderia" class="form-label fw-semibold">
                                Mercadería
                            </label>
                            <textarea id="mercaderia" name="mercaderia" class="form-control <?php $__errorArgs = ['mercaderia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                rows="3" maxlength="255"><?php echo e(old('mercaderia')); ?></textarea>
                            <?php $__errorArgs = ['mercaderia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="num_factura" class="form-label fw-semibold">Número de factura</label>
                            <input type="text" id="num_factura" name="num_factura" value="<?php echo e(old('num_factura')); ?>" class="form-control" maxlength="255">
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="peso" class="form-label fw-semibold">Peso</label>
                            <div class="input-group">
                                <input type="number" id="peso" name="peso" value="<?php echo e(old('peso')); ?>" class="form-control <?php $__errorArgs = ['peso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" min="0" step="0.01">
                                <span class="input-group-text">kg</span>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="volumen" class="form-label fw-semibold">
                                Metros cúbicos
                            </label>
                            <div class="input-group">
                                <input type="number" id="volumen" name="volumen" value="<?php echo e(old('volumen')); ?>"
                                    class="form-control <?php $__errorArgs = ['volumen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" min="0"
                                    step="0.01">
                                <span class="input-group-text">
                                    m³
                                </span>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="cantidad_bultos" class="form-label fw-semibold">
                                Cantidad de bultos
                            </label>
                            <input type="number" id="cantidad_bultos" name="cantidad_bultos"
                                value="<?php echo e(old('cantidad_bultos')); ?>" class="form-control" min="0">
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="tipo_bulto" class="form-label fw-semibold">
                                Tipo de bulto
                            </label>
                            <input type="text" id="tipo_bulto" name="tipo_bulto" value="<?php echo e(old('tipo_bulto')); ?>"
                                class="form-control" maxlength="255" placeholder="Ej.: pallets, cajas o bolsas">
                        </div>
                    </div>
                </div>
            </section>
            <section class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-dark text-white py-3">
                    <h2 class="h5 mb-0">
                        Carga y recorrido
                    </h2>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-12 col-md-4">
                            <label for="ciudad_carga" class="form-label fw-semibold">
                                Ciudad de carga
                            </label>
                            <input type="text" id="ciudad_carga" name="ciudad_carga"
                                value="<?php echo e(old('ciudad_carga')); ?>" class="form-control" maxlength="255">
                        </div>
                        <div class="col-12 col-md-4">
                            <label for="frontera" class="form-label fw-semibold">
                                Frontera
                            </label>
                            <input type="text" id="frontera" name="frontera" value="<?php echo e(old('frontera')); ?>"
                                class="form-control" maxlength="255">
                        </div>
                        <div class="col-12 col-md-4">
                            <label for="coleta" class="form-label fw-semibold">
                                Coleta
                            </label>
                            <input type="text" id="coleta" name="coleta" value="<?php echo e(old('coleta')); ?>"
                                class="form-control" maxlength="255">
                        </div>
                    </div>
                </div>
            </section>
            <section class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-dark text-white py-3">
                    <h2 class="h5 mb-0">
                        Descarga
                    </h2>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-12 col-md-6">
                            <label for="ciudad_descarga" class="form-label fw-semibold">
                                Ciudad de descarga
                            </label>
                            <input type="text" id="ciudad_descarga" name="ciudad_descarga"
                                value="<?php echo e(old('ciudad_descarga')); ?>" class="form-control" maxlength="255">
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="direccion_descarga" class="form-label fw-semibold">
                                Dirección de descarga
                            </label>
                            <input type="text" id="direccion_descarga" name="direccion_descarga"
                                value="<?php echo e(old('direccion_descarga')); ?>" class="form-control" maxlength="255">
                        </div>
                        <div class="col-12 col-md-4">
                            <label for="telefono_descarga" class="form-label fw-semibold">
                                Teléfono
                            </label>
                            <input type="tel" id="telefono_descarga" name="telefono_descarga"
                                value="<?php echo e(old('telefono_descarga')); ?>" class="form-control" maxlength="50">
                        </div>
                        <div class="col-12 col-md-4">
                            <label for="contacto_descarga" class="form-label fw-semibold">
                                Contacto
                            </label>
                            <input type="text" id="contacto_descarga" name="contacto_descarga"
                                value="<?php echo e(old('contacto_descarga')); ?>" class="form-control" maxlength="255">
                        </div>
                        <div class="col-12 col-md-4">
                            <label for="email_descarga" class="form-label fw-semibold">
                                Email
                            </label>
                            <input type="email" id="email_descarga" name="email_descarga"
                                value="<?php echo e(old('email_descarga')); ?>"
                                class="form-control <?php $__errorArgs = ['email_descarga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" maxlength="255">
                        </div>
                    </div>
                </div>
            </section>
            <section class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-dark text-white py-3">
                    <h2 class="h5 mb-0">
                        Despachante nacional
                    </h2>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-12">
                            <label for="selector_despachante_local" class="form-label fw-semibold">Seleccionar despachante local</label>
                            <select id="selector_despachante_local" class="form-select">
                                <option value="">Seleccionar despachante registrado</option>
                                <?php $__currentLoopData = $despachantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $despachante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($despachante->id); ?>"
                                    data-nombre="<?php echo e($despachante->nombre); ?>"
                                    data-email="<?php echo e($despachante->email); ?>"
                                    data-telefono="<?php echo e($despachante->telefono); ?>"
                                    data-direccion="<?php echo e($despachante->direccion); ?>"
                                    data-gestor="<?php echo e($despachante->gestor); ?>"
                                    data-gestor-telefono="<?php echo e($despachante->gestor_telefono); ?>"
                                    data-contacto="<?php echo e($despachante->contacto); ?>">
                                    <?php echo e($despachante->nombre); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="form-text">Al seleccionar un despachante, se completan sus datos. Podés editarlos antes de guardar la ficha.</div>
                        </div>

                        <div class="col-12 col-md-6">
                            <label for="despachante_uy" class="form-label fw-semibold">
                                Despachante
                            </label>
                            <input type="text" id="despachante_uy" name="despachante_uy"
                                value="<?php echo e(old('despachante_uy')); ?>" class="form-control" maxlength="255">
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="email_despachante" class="form-label fw-semibold">
                                Email
                            </label>
                            <input type="email" id="email_despachante" name="email_despachante"
                                value="<?php echo e(old('email_despachante')); ?>"
                                class="form-control <?php $__errorArgs = ['email_despachante'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                maxlength="255">
                        </div>
                        <div class="col-12 col-md-4">
                            <label for="telefono_despachante" class="form-label fw-semibold">
                                Teléfono
                            </label>
                            <input type="tel" id="telefono_despachante" name="telefono_despachante"
                                value="<?php echo e(old('telefono_despachante')); ?>" class="form-control" maxlength="50">
                        </div>
                        <div class="col-12 col-md-8">
                            <label for="direccion_despachante" class="form-label fw-semibold">
                                Dirección
                            </label>
                            <input type="text" id="direccion_despachante" name="direccion_despachante"
                                value="<?php echo e(old('direccion_despachante')); ?>" class="form-control" maxlength="255">
                        </div>
                        <div class="col-12 col-md-4">
                            <label for="gestor" class="form-label fw-semibold">
                                Gestor
                            </label>
                            <input type="text" id="gestor" name="gestor" value="<?php echo e(old('gestor')); ?>"
                                class="form-control" maxlength="255">
                        </div>
                        <div class="col-12 col-md-4">
                            <label for="telefono_gestor" class="form-label fw-semibold">
                                Teléfono del gestor
                            </label>
                            <input type="tel" id="telefono_gestor" name="telefono_gestor"
                                value="<?php echo e(old('telefono_gestor')); ?>" class="form-control" maxlength="50">
                        </div>
                        <div class="col-12 col-md-4">
                            <label for="dua" class="form-label fw-semibold">
                                DUA
                            </label>
                            <input type="text" id="dua" name="dua" value="<?php echo e(old('dua')); ?>"
                                class="form-control <?php $__errorArgs = ['dua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" inputmode="numeric"
                                maxlength="6" pattern="[0-9]{1,6}" placeholder="Hasta 6 números">
                            <?php $__errorArgs = ['dua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12">
                            <label for="contacto_despachante" class="form-label fw-semibold">
                                Contacto
                            </label>
                            <input type="text" id="contacto_despachante" name="contacto_despachante"
                                value="<?php echo e(old('contacto_despachante')); ?>" class="form-control" maxlength="255">
                        </div>
                    </div>
                </div>
            </section>
            <section class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-dark text-white py-3">
                    <h2 class="h5 mb-0">
                        Información comercial
                    </h2>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-12 col-md-6">
                            <label for="hecha_por" class="form-label fw-semibold">
                                Hecha por
                            </label>
                            <input type="text" id="hecha_por" name="hecha_por" value="<?php echo e(old('hecha_por')); ?>"
                                class="form-control
                                        <?php $__errorArgs = ['hecha_por'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                maxlength="255">
                            <?php $__errorArgs = ['hecha_por'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="fecha_comercial" class="form-label fw-semibold">
                                Fecha
                            </label>
                            <input type="date" id="fecha_comercial" name="fecha_comercial"
                                value="<?php echo e(old('fecha_comercial')); ?>"
                                class="form-control
                                        <?php $__errorArgs = ['fecha_comercial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['fecha_comercial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12">
                            <hr>
                            <h3 class="h6 fw-bold mb-0">
                                Fletes e importes
                            </h3>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4">
                            <label for="puesta_fob" class="form-label fw-semibold">
                                Puesta a FOB
                            </label>
                            <div class="input-group">
                                <span class="input-group-text">
                                    US$
                                </span>
                                <input type="number" id="puesta_fob" name="puesta_fob"
                                    value="<?php echo e(old('puesta_fob')); ?>"
                                    class="form-control
                                            <?php $__errorArgs = ['puesta_fob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    min="0" step="0.01">
                                <?php $__errorArgs = ['puesta_fob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4">
                            <label for="flete_internacional" class="form-label fw-semibold">
                                Flete internacional
                            </label>
                            <div class="input-group">
                                <span class="input-group-text">
                                    US$
                                </span>
                                <input type="number" id="flete_internacional" name="flete_internacional"
                                    value="<?php echo e(old('flete_internacional')); ?>"
                                    class="form-control
                                            <?php $__errorArgs = ['flete_internacional'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    min="0" step="0.01">
                                <?php $__errorArgs = ['flete_internacional'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4">
                            <label for="flete_nacional" class="form-label fw-semibold">
                                Flete nacional
                            </label>
                            <div class="input-group">
                                <span class="input-group-text">
                                    US$
                                </span>
                                <input type="number" id="flete_nacional" name="flete_nacional"
                                    value="<?php echo e(old('flete_nacional')); ?>"
                                    class="form-control
                                            <?php $__errorArgs = ['flete_nacional'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    min="0" step="0.01">
                                <?php $__errorArgs = ['flete_nacional'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4">
                            <label for="ad_valorem_porcentaje" class="form-label fw-semibold">
                                Porcentaje de ad valorem
                            </label>
                            <div class="input-group">
                                <input type="number" id="ad_valorem_porcentaje" name="ad_valorem_porcentaje"
                                    value="<?php echo e(old('ad_valorem_porcentaje')); ?>"
                                    class="form-control
                                            <?php $__errorArgs = ['ad_valorem_porcentaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    min="0" max="100" step="0.01">
                                <span class="input-group-text">
                                    %
                                </span>
                                <?php $__errorArgs = ['ad_valorem_porcentaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4">
                            <label for="ad_valorem" class="form-label fw-semibold">
                                Valor del ad valorem
                            </label>
                            <div class="input-group">
                                <span class="input-group-text">
                                    US$
                                </span>
                                <input type="number" id="ad_valorem" name="ad_valorem"
                                    value="<?php echo e(old('ad_valorem')); ?>"
                                    class="form-control
                                            <?php $__errorArgs = ['ad_valorem'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    min="0" step="0.01">
                                <?php $__errorArgs = ['ad_valorem'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4">
                            <label for="despacho_brasil" class="form-label fw-semibold">
                                Despacho de Brasil
                            </label>
                            <div class="input-group">
                                <span class="input-group-text">
                                    US$
                                </span>
                                <input type="number" id="despacho_brasil" name="despacho_brasil"
                                    value="<?php echo e(old('despacho_brasil')); ?>"
                                    class="form-control
                                            <?php $__errorArgs = ['despacho_brasil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    min="0" step="0.01">
                                <?php $__errorArgs = ['despacho_brasil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4">
                            <label for="total_comercial" class="form-label fw-semibold">
                                Total
                            </label>
                            <div class="input-group">
                                <span class="input-group-text">
                                    US$
                                </span>
                                <input type="number" id="total_comercial" name="total_comercial"
                                    value="<?php echo e(old('total_comercial')); ?>" class="form-control" step="0.01"
                                    readonly>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="fob_usd" class="form-label fw-semibold">
                                FOB US$
                            </label>
                            <div class="input-group">
                                <span class="input-group-text">
                                    US$
                                </span>
                                <input type="number" id="fob_usd" name="fob_usd" value="<?php echo e(old('fob_usd')); ?>"
                                    class="form-control
                                            <?php $__errorArgs = ['fob_usd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    min="0" step="0.01">
                                <?php $__errorArgs = ['fob_usd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="flete_por_camion" class="form-label fw-semibold">
                                Flete por camión
                            </label>
                            <input type="text" id="flete_por_camion" name="flete_por_camion"
                                value="<?php echo e(old('flete_por_camion')); ?>"
                                class="form-control <?php $__errorArgs = ['flete_por_camion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" maxlength="255"
                                placeholder="Información del flete por camión">
                            <?php $__errorArgs = ['flete_por_camion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12">
                            <hr>
                            <h3 class="h6 fw-bold mb-0">
                                Facturación y transporte
                            </h3>
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="proforma" class="form-label fw-semibold">
                                Proforma
                            </label>
                            <input type="text" id="proforma" name="proforma" value="<?php echo e(old('proforma')); ?>"
                                class="form-control
                                        <?php $__errorArgs = ['proforma'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                maxlength="255" placeholder="Letras y números">
                            <?php $__errorArgs = ['proforma'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="factura_definitiva" class="form-label fw-semibold">
                                Factura definitiva
                            </label>
                            <input type="text" id="factura_definitiva" name="factura_definitiva"
                                value="<?php echo e(old('factura_definitiva')); ?>"
                                class="form-control
                                        <?php $__errorArgs = ['factura_definitiva'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                maxlength="255" placeholder="Letras y números">
                            <?php $__errorArgs = ['factura_definitiva'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="cantidad_camiones" class="form-label fw-semibold">
                                Cantidad de camiones
                            </label>
                            <input type="number" id="cantidad_camiones" name="cantidad_camiones"
                                value="<?php echo e(old('cantidad_camiones')); ?>"
                                class="form-control
                                        <?php $__errorArgs = ['cantidad_camiones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                min="0" step="1">
                            <?php $__errorArgs = ['cantidad_camiones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12">
                            <label for="observaciones_comerciales" class="form-label fw-semibold">
                                Observaciones
                            </label>
                            <textarea id="observaciones_comerciales" name="observaciones_comerciales"
                                class="form-control
                                        <?php $__errorArgs = ['observaciones_comerciales'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                rows="4" maxlength="5000" placeholder="Información comercial adicional"><?php echo e(old('observaciones_comerciales')); ?></textarea>
                            <?php $__errorArgs = ['observaciones_comerciales'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </section>
            <div class="d-flex flex-column flex-sm-row justify-content-end gap-2">
                <a href="<?php echo e(route('panel.fichas.index')); ?>" class="btn btn-outline-secondary">
                    Cancelar
                </a>
                <button type="submit" class="btn btn-warning fw-bold">
                    <i class="bi bi-file-earmark-check-fill me-2"></i>
                    Registrar ficha
                </button>
            </div>
        </form>
    </main>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Fefog\Desktop\Proyecto-Final\Translogistica\resources\views\panel\fichas\create.blade.php ENDPATH**/ ?>