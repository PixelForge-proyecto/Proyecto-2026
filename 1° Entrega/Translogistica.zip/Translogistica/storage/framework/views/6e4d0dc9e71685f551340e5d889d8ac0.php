<?php $__env->startSection('title', 'Seguimientos | Translogística'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-vh-100 bg-light">
    <?php if (isset($component)) { $__componentOriginalbe062454937ca58204f074f7f20cd3ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbe062454937ca58204f074f7f20cd3ac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.panel-navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('panel-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbe062454937ca58204f074f7f20cd3ac)): ?>
<?php $attributes = $__attributesOriginalbe062454937ca58204f074f7f20cd3ac; ?>
<?php unset($__attributesOriginalbe062454937ca58204f074f7f20cd3ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbe062454937ca58204f074f7f20cd3ac)): ?>
<?php $component = $__componentOriginalbe062454937ca58204f074f7f20cd3ac; ?>
<?php unset($__componentOriginalbe062454937ca58204f074f7f20cd3ac); ?>
<?php endif; ?>

    <main class="container py-5">
        <div
            class="d-flex flex-column flex-md-row
                    justify-content-between align-items-md-center
                    gap-3 mb-4">
            <div>
                <h1 class="fw-bold mb-1">
                    Seguimientos
                </h1>

                <p class="text-secondary mb-0">
                    Consulta y actualización del estado
                    de las cargas.
                </p>
            </div>

            <a
                href="<?php echo e(route('panel.seguimientos.create')); ?>"
                class="btn btn-warning fw-bold">
                <i class="bi bi-plus-circle me-2"></i>
                Nuevo seguimiento
            </a>
        </div>

        <?php if(session('status')): ?>
        <div
            class="alert alert-success"
            role="alert">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>

        <section class="card border-0 shadow-sm mb-4">
            <div class="card-body">
                <form
                    method="GET"
                    action="<?php echo e(route('panel.seguimientos.index')); ?>">
                    <div class="row g-3 align-items-end">
                        <div class="col-12 col-lg-5">
                            <label
                                for="buscar-seguimiento"
                                class="form-label fw-semibold">
                                Buscar operación
                            </label>

                            <input
                                type="search"
                                id="buscar-seguimiento"
                                name="buscar"
                                value="<?php echo e($buscar); ?>"
                                class="form-control"
                                placeholder="Ficha, CRT, DUA o cliente">
                        </div>

                        <div class="col-12 col-md-7 col-lg-4">
                            <label
                                for="filtro-etapa"
                                class="form-label fw-semibold">
                                Etapa
                            </label>

                            <select
                                id="filtro-etapa"
                                name="etapa"
                                class="form-select">
                                <option value="">
                                    Todas
                                </option>

                                <option
                                    value="carga"
                                    <?php if($etapa==='carga' ): echo 'selected'; endif; ?>>
                                    Carga
                                </option>

                                <option
                                    value="deposito"
                                    <?php if($etapa==='deposito' ): echo 'selected'; endif; ?>>
                                    Depósito
                                </option>

                                <option
                                    value="frontera"
                                    <?php if($etapa==='frontera' ): echo 'selected'; endif; ?>>
                                    Frontera
                                </option>

                                <option
                                    value="aduana_internacional"
                                    <?php if($etapa==='aduana_internacional' ): echo 'selected'; endif; ?>>
                                    Aduana internacional
                                </option>

                                <option
                                    value="aduana_nacional"
                                    <?php if($etapa==='aduana_nacional' ): echo 'selected'; endif; ?>>
                                    Aduana nacional
                                </option>

                                <option
                                    value="liberacion"
                                    <?php if($etapa==='liberacion' ): echo 'selected'; endif; ?>>
                                    Liberación
                                </option>

                                <option
                                    value="entrega"
                                    <?php if($etapa==='entrega' ): echo 'selected'; endif; ?>>
                                    Entrega
                                </option>
                            </select>
                        </div>

                        <div class="col-12 col-md-5 col-lg-3">
                            <button
                                type="submit"
                                class="btn btn-dark w-100">
                                <i class="bi bi-search me-2"></i>
                                Buscar
                            </button>
                        </div>
                    </div>

                    <?php if($buscar !== '' || $etapa !== ''): ?>
                    <div class="mt-3">
                        <a
                            href="<?php echo e(route('panel.seguimientos.index')); ?>"
                            class="text-decoration-none">
                            Limpiar filtros
                        </a>
                    </div>
                    <?php endif; ?>
                </form>
            </div>
        </section>

        <section class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h2 class="h5 fw-bold mb-0">
                    Operaciones en seguimiento
                </h2>
            </div>

            <div class="table-responsive">
                <table
                    class="table table-hover
                            align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th scope="col">
                                Ficha
                            </th>

                            <th scope="col">
                                CRT
                            </th>

                            <th scope="col">
                                Cliente
                            </th>

                            <th scope="col">
                                Etapa actual
                            </th>

                            <th scope="col">
                                Última fecha
                            </th>

                            <th
                                scope="col"
                                class="text-end">
                                Acciones
                            </th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $seguimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seguimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                        $nombreEtapa = match (
                        $seguimiento->etapa
                        ) {
                        'carga' =>
                        'Carga',

                        'deposito' =>
                        'Depósito',

                        'frontera' =>
                        'Frontera',

                        'aduana_internacional' =>
                        'Aduana internacional',

                        'aduana_nacional' =>
                        'Aduana nacional',

                        'liberacion' =>
                        'Liberación',

                        'entrega' =>
                        'Entrega',

                        default =>
                        'Sin especificar',
                        };

                        $colorEtapa = match (
                        $seguimiento->etapa
                        ) {
                        'carga' =>
                        'secondary',

                        'deposito' =>
                        'info',

                        'frontera' =>
                        'warning',

                        'aduana_internacional' =>
                        'dark',

                        'aduana_nacional' =>
                        'primary',

                        'liberacion' =>
                        'primary',

                        'entrega' =>
                        'success',

                        default =>
                        'secondary',
                        };
                        ?>

                        <tr>
                            <td>
                                <?php echo e($seguimiento->ficha->num_ficha ?? $seguimiento->ficha->id); ?>

                            </td>

                            <td>
                                <?php echo e($seguimiento->ficha->num_crt ?? 'Sin especificar'); ?>

                            </td>

                            <td>
                                <?php echo e($seguimiento->ficha->cliente?->nombre ?? 'Sin especificar'); ?>

                            </td>

                            <td>
                                <span
                                    class="badge
                                                text-bg-<?php echo e($colorEtapa); ?>">
                                    <?php echo e($nombreEtapa); ?>

                                </span>
                            </td>

                            <td>
                                <?php echo e($seguimiento->fecha?->format('d/m/Y') ?? 'Sin especificar'); ?>

                            </td>

                            <td class="text-end">
                                <a
                                    href="<?php echo e(route('panel.seguimientos.show', $seguimiento)); ?>"
                                    class="btn btn-sm
                                                btn-outline-dark">
                                    Ver detalle
                                </a>

                                <a
                                    href="<?php echo e(route('panel.seguimientos.edit', $seguimiento)); ?>"
                                    class="btn btn-sm
                                                btn-warning">
                                    Actualizar
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td
                                colspan="6"
                                class="text-center
                                            text-secondary py-5">
                                No hay seguimientos que
                                coincidan con la búsqueda.
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="card-footer bg-white text-secondary">
                Se muestra el seguimiento más reciente
                de cada ficha.
            </div>
        </section>
    </main>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Fefog\Desktop\Proyecto-Final\Translogistica\resources\views/panel/seguimientos/index.blade.php ENDPATH**/ ?>