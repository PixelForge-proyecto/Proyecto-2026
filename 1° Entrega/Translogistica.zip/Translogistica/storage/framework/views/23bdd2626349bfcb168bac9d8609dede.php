<?php $__env->startSection('title', 'Estado de la carga | Translogística'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-vh-100 bg-light">
    <?php if (isset($component)) { $__componentOriginal19fff246197017a876e8761e85e28801 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19fff246197017a876e8761e85e28801 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cliente-navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cliente-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19fff246197017a876e8761e85e28801)): ?>
<?php $attributes = $__attributesOriginal19fff246197017a876e8761e85e28801; ?>
<?php unset($__attributesOriginal19fff246197017a876e8761e85e28801); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19fff246197017a876e8761e85e28801)): ?>
<?php $component = $__componentOriginal19fff246197017a876e8761e85e28801; ?>
<?php unset($__componentOriginal19fff246197017a876e8761e85e28801); ?>
<?php endif; ?>

    <main class="container py-5">
        <div
            class="d-flex flex-column flex-md-row
                    justify-content-between align-items-md-center
                    gap-3 mb-4">
            <div>
                <h1 class="fw-bold mb-1">
                    Estado de la carga
                </h1>

                <p class="text-secondary mb-0">
                    Información y seguimiento de la operación.
                </p>
            </div>

            <a
                href="<?php echo e(route('cliente.cargas.index')); ?>"
                class="btn btn-outline-dark">
                <i class="bi bi-arrow-left me-2"></i>
                Volver a mis cargas
            </a>
        </div>

        <section class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-dark text-white py-3">
                <h2 class="h5 fw-bold mb-0">
                    Datos de la operación
                </h2>
            </div>

            <div class="card-body">
                <div class="row g-4">
                    <div class="col-12 col-md-6 col-lg-4">
                        <small class="text-secondary d-block">
                            Número de CRT
                        </small>

                        <span class="fw-semibold">
                            <?php echo e($carga['crt']); ?>

                        </span>
                    </div>

                    <div class="col-12 col-md-6 col-lg-4">
                        <small class="text-secondary d-block">
                            Número de DUA
                        </small>

                        <span class="fw-semibold">
                            <?php echo e($carga['dua']); ?>

                        </span>
                    </div>

                    <div class="col-12 col-md-6 col-lg-4">
                        <small class="text-secondary d-block">
                            Tipo de operación
                        </small>

                        <span class="fw-semibold">
                            <?php echo e($carga['operacion']); ?>

                        </span>
                    </div>

                    <div class="col-12 col-md-6 col-lg-4">
                        <small class="text-secondary d-block">
                            Estado actual
                        </small>

                        <span class="fw-semibold">
                            <?php echo e($carga['estado']); ?>

                        </span>
                    </div>

                    <div class="col-12 col-md-6 col-lg-4">
                        <small class="text-secondary d-block">
                            Ciudad de origen
                        </small>

                        <span class="fw-semibold">
                            <?php echo e($carga['origen']); ?>

                        </span>
                    </div>

                    <div class="col-12 col-md-6 col-lg-4">
                        <small class="text-secondary d-block">
                            Ciudad de destino
                        </small>

                        <span class="fw-semibold">
                            <?php echo e($carga['destino']); ?>

                        </span>
                    </div>

                    <div class="col-12 col-md-6 col-lg-4">
                        <small class="text-secondary d-block">
                            Paso fronterizo
                        </small>

                        <span class="fw-semibold">
                            <?php echo e($carga['frontera']); ?>

                        </span>
                    </div>
                </div>
            </div>
        </section>

        <section class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h2 class="h5 fw-bold mb-0">
                    Seguimiento
                </h2>
            </div>

            <div class="card-body p-4">
                <div class="row g-4">
                    
                    <div class="col-12 col-md-6">
                        <div class="border rounded p-3 h-100">
                            <div
                                class="d-flex align-items-center gap-3">
                                <?php if($carga['fecha_carga']): ?>
                                <i
                                    class="bi bi-check-circle-fill
                                                fs-3 text-success"></i>
                                <?php else: ?>
                                <i
                                    class="bi bi-clock-fill
                                                fs-3 text-secondary"></i>
                                <?php endif; ?>

                                <div>
                                    <h3 class="h6 fw-bold mb-1">
                                        Carga
                                    </h3>

                                    <?php if($carga['fecha_carga']): ?>
                                    <p class="mb-0">
                                        <?php echo e($carga['fecha_carga']); ?>

                                    </p>
                                    <?php else: ?>
                                    <p class="text-secondary mb-0">
                                        Pendiente
                                    </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="col-12 col-md-6">
                        <div class="border rounded p-3 h-100">
                            <div
                                class="d-flex align-items-center gap-3">
                                <?php if($carga['fecha_deposito']): ?>
                                <i
                                    class="bi bi-check-circle-fill
                                                fs-3 text-success"></i>
                                <?php else: ?>
                                <i
                                    class="bi bi-dash-circle-fill
                                                fs-3 text-secondary"></i>
                                <?php endif; ?>

                                <div>
                                    <h3 class="h6 fw-bold mb-1">
                                        Llegada al depósito
                                    </h3>

                                    <?php if($carga['fecha_deposito']): ?>
                                    <p class="mb-0">
                                        <?php echo e($carga['fecha_deposito']); ?>

                                    </p>
                                    <?php else: ?>
                                    <p class="text-secondary mb-0">
                                        Sin registro
                                    </p>

                                    <small class="text-secondary">
                                        Etapa opcional
                                    </small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="col-12 col-md-6">
                        <div class="border rounded p-3 h-100">
                            <div
                                class="d-flex align-items-center gap-3">
                                <?php if($carga['fecha_frontera']): ?>
                                <i
                                    class="bi bi-check-circle-fill
                                                fs-3 text-success"></i>
                                <?php else: ?>
                                <i
                                    class="bi bi-clock-fill
                                                fs-3 text-secondary"></i>
                                <?php endif; ?>

                                <div>
                                    <h3 class="h6 fw-bold mb-1">
                                        Frontera
                                    </h3>

                                    <?php if($carga['fecha_frontera']): ?>
                                    <p class="mb-0">
                                        <?php echo e($carga['fecha_frontera']); ?>

                                    </p>
                                    <?php else: ?>
                                    <p class="text-secondary mb-0">
                                        Pendiente
                                    </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="col-12 col-md-6">
                        <div class="border rounded p-3 h-100">
                            <div
                                class="d-flex align-items-start gap-3">
                                <?php if(!$carga['fecha_aduana_internacional']): ?>
                                <i
                                    class="bi bi-dash-circle-fill
                                                fs-3 text-secondary"></i>
                                <?php elseif($carga['canal_aduana_internacional'] === 'verde'): ?>
                                <i
                                    class="bi bi-check-circle-fill
                                                fs-3 text-success"></i>
                                <?php elseif($carga['canal_aduana_internacional'] === 'naranja'): ?>
                                <i
                                    class="bi bi-exclamation-circle-fill
                                                fs-3 text-warning"></i>
                                <?php elseif($carga['canal_aduana_internacional'] === 'rojo'): ?>
                                <i
                                    class="bi bi-exclamation-triangle-fill
                                                fs-3 text-danger"></i>
                                <?php else: ?>
                                <i
                                    class="bi bi-check-circle-fill
                                                fs-3 text-success"></i>
                                <?php endif; ?>

                                <div>
                                    <h3 class="h6 fw-bold mb-1">
                                        Aduana internacional
                                    </h3>

                                    <?php if($carga['fecha_aduana_internacional']): ?>
                                    <p class="mb-2">
                                        <?php echo e($carga['fecha_aduana_internacional']); ?>

                                    </p>

                                    <?php if($carga['canal_aduana_internacional'] === 'verde'): ?>
                                    <span
                                        class="badge text-bg-success">
                                        Canal verde
                                    </span>
                                    <?php elseif($carga['canal_aduana_internacional'] === 'naranja'): ?>
                                    <span
                                        class="badge text-bg-warning">
                                        Canal naranja
                                    </span>
                                    <?php elseif($carga['canal_aduana_internacional'] === 'rojo'): ?>
                                    <span
                                        class="badge text-bg-danger">
                                        Canal rojo
                                    </span>
                                    <?php else: ?>
                                    <span class="text-secondary">
                                        Canal sin especificar
                                    </span>
                                    <?php endif; ?>
                                    <?php else: ?>
                                    <p class="text-secondary mb-0">
                                        Sin registro
                                    </p>

                                    <small class="text-secondary">
                                        Puede no corresponder
                                    </small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="col-12 col-md-6">
                        <div class="border rounded p-3 h-100">
                            <div
                                class="d-flex align-items-start gap-3">
                                <?php if(!$carga['fecha_aduana_nacional']): ?>
                                <i
                                    class="bi bi-dash-circle-fill
                                                fs-3 text-secondary"></i>
                                <?php elseif($carga['canal_aduana_nacional'] === 'verde'): ?>
                                <i
                                    class="bi bi-check-circle-fill
                                                fs-3 text-success"></i>
                                <?php elseif($carga['canal_aduana_nacional'] === 'naranja'): ?>
                                <i
                                    class="bi bi-exclamation-circle-fill
                                                fs-3 text-warning"></i>
                                <?php elseif($carga['canal_aduana_nacional'] === 'rojo'): ?>
                                <i
                                    class="bi bi-exclamation-triangle-fill
                                                fs-3 text-danger"></i>
                                <?php else: ?>
                                <i
                                    class="bi bi-check-circle-fill
                                                fs-3 text-success"></i>
                                <?php endif; ?>

                                <div>
                                    <h3 class="h6 fw-bold mb-1">
                                        Aduana nacional
                                    </h3>

                                    <?php if($carga['fecha_aduana_nacional']): ?>
                                    <p class="mb-2">
                                        <?php echo e($carga['fecha_aduana_nacional']); ?>

                                    </p>

                                    <?php if($carga['canal_aduana_nacional'] === 'verde'): ?>
                                    <span
                                        class="badge text-bg-success">
                                        Canal verde
                                    </span>
                                    <?php elseif($carga['canal_aduana_nacional'] === 'naranja'): ?>
                                    <span
                                        class="badge text-bg-warning">
                                        Canal naranja
                                    </span>
                                    <?php elseif($carga['canal_aduana_nacional'] === 'rojo'): ?>
                                    <span
                                        class="badge text-bg-danger">
                                        Canal rojo
                                    </span>
                                    <?php else: ?>
                                    <span class="text-secondary">
                                        Canal sin especificar
                                    </span>
                                    <?php endif; ?>
                                    <?php else: ?>
                                    <p class="text-secondary mb-0">
                                        Sin registro
                                    </p>

                                    <small class="text-secondary">
                                        Puede no corresponder
                                    </small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="col-12 col-md-6">
                        <div class="border rounded p-3 h-100">
                            <div
                                class="d-flex align-items-center gap-3">
                                <?php if($carga['fecha_liberacion']): ?>
                                <i
                                    class="bi bi-check-circle-fill
                                                fs-3 text-success"></i>
                                <?php else: ?>
                                <i
                                    class="bi bi-clock-fill
                                                fs-3 text-secondary"></i>
                                <?php endif; ?>

                                <div>
                                    <h3 class="h6 fw-bold mb-1">
                                        Liberación
                                    </h3>

                                    <?php if($carga['fecha_liberacion']): ?>
                                    <p class="mb-0">
                                        <?php echo e($carga['fecha_liberacion']); ?>

                                    </p>
                                    <?php else: ?>
                                    <p class="text-secondary mb-0">
                                        Pendiente
                                    </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="col-12 col-md-6">
                        <div class="border rounded p-3 h-100">
                            <div
                                class="d-flex align-items-center gap-3">
                                <?php if($carga['fecha_entrega']): ?>
                                <i
                                    class="bi bi-check-circle-fill
                                                fs-3 text-success"></i>
                                <?php else: ?>
                                <i
                                    class="bi bi-clock-fill
                                                fs-3 text-secondary"></i>
                                <?php endif; ?>

                                <div>
                                    <h3 class="h6 fw-bold mb-1">
                                        Entrega
                                    </h3>

                                    <?php if($carga['fecha_entrega']): ?>
                                    <p class="mb-0">
                                        <?php echo e($carga['fecha_entrega']); ?>

                                    </p>
                                    <?php else: ?>
                                    <p class="text-secondary mb-0">
                                        Pendiente
                                    </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="col-12">
                        <section class="border rounded p-4">
                            <div
                                class="d-flex align-items-center
                                        gap-2 mb-3">
                                <i
                                    class="bi bi-chat-left-text-fill
                                            text-warning fs-4"></i>

                                <h3 class="h5 fw-bold mb-0">
                                    Historial de observaciones
                                </h3>
                            </div>

                            <?php $__empty_1 = true; $__currentLoopData = $carga['observaciones']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $observacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <article
                                class="bg-light border rounded
                                            p-3 mb-3">
                                <div
                                    class="d-flex flex-column
                                                flex-sm-row
                                                justify-content-between
                                                gap-2 mb-2">
                                    <strong>
                                        <?php echo e($observacion['etapa']); ?>

                                    </strong>

                                    <span class="text-secondary">
                                        <i
                                            class="bi bi-calendar3 me-1"></i>

                                        <?php echo e($observacion['fecha']); ?>

                                    </span>
                                </div>

                                <p class="mb-0">
                                    <?php echo e($observacion['texto']); ?>

                                </p>
                            </article>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div
                                class="alert alert-light
                                            border mb-0">
                                <p class="text-secondary mb-0">
                                    No hay observaciones comunicadas
                                    para esta carga.
                                </p>
                            </div>
                            <?php endif; ?>
                        </section>
                    </div>
                </div>
            </div>

            <div class="card-footer bg-white text-secondary">
                Información actualizada desde el seguimiento
                de la carga.
            </div>
        </section>
    </main>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Fefog\Desktop\Proyecto-Final\Translogistica\resources\views\cliente\carga.blade.php ENDPATH**/ ?>