<?php $__env->startSection('title', 'Registrar cliente | Translogística'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-vh-100 bg-light">
    <?php if (isset($component)) { $__componentOriginalbe062454937ca58204f074f7f20cd3ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbe062454937ca58204f074f7f20cd3ac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.panel-navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('panel-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbe062454937ca58204f074f7f20cd3ac)): ?>
<?php $attributes = $__attributesOriginalbe062454937ca58204f074f7f20cd3ac; ?>
<?php unset($__attributesOriginalbe062454937ca58204f074f7f20cd3ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbe062454937ca58204f074f7f20cd3ac)): ?>
<?php $component = $__componentOriginalbe062454937ca58204f074f7f20cd3ac; ?>
<?php unset($__componentOriginalbe062454937ca58204f074f7f20cd3ac); ?>
<?php endif; ?>

    <main class="container py-5">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-8">
                <div class="mb-4">
                    <a href="<?php echo e(route('panel.clientes.index')); ?>" class="text-decoration-none">
                        <i class="bi bi-arrow-left me-1"></i>
                        Volver a clientes
                    </a>
                </div>

                <section class="card border-0 shadow-sm">
                    <div class="card-body p-4 p-md-5">
                        <div class="mb-4">
                            <h1 class="fw-bold mb-2">Registrar cliente</h1>
                            <p class="text-secondary mb-0" id="descripcion-cliente">
                                Seleccioná el país para registrar un cliente nacional o internacional.
                            </p>
                        </div>

                        <div class="alert alert-info" role="alert" id="aviso-cliente">
                            Los clientes de Uruguay, Brasil y Argentina pueden acceder al portal con sus credenciales.
                        </div>

                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger" role="alert">
                            Revisá los campos señalados antes de continuar.
                        </div>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route('panel.clientes.store')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="row g-4">
                                <div class="col-12 col-md-6">
                                    <label for="origen" class="form-label fw-semibold">País de origen</label>
                                    <select id="origen" name="origen"
                                        class="form-select <?php $__errorArgs = ['origen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="" disabled <?php if(old('origen')===null): echo 'selected'; endif; ?>>Seleccionar</option>
                                        <option value="local" <?php if(old('origen')==='local' ): echo 'selected'; endif; ?>>Uruguay</option>
                                        <option value="brasil" <?php if(old('origen')==='brasil' ): echo 'selected'; endif; ?>>Brasil</option>
                                        <option value="argentina" <?php if(old('origen')==='argentina' ): echo 'selected'; endif; ?>>Argentina</option>
                                    </select>
                                    <?php $__errorArgs = ['origen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-12 col-md-6">
                                    <label for="nombre" class="form-label fw-semibold">Nombre del cliente</label>
                                    <input type="text" id="nombre" name="nombre" value="<?php echo e(old('nombre')); ?>"
                                        class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Nombre o razón social" maxlength="255" required>
                                    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-12 col-md-6" data-solo-nacional hidden>
                                    <label for="ruc_rut" class="form-label fw-semibold">
                                        RUC / RUT <span class="text-secondary fw-normal">(opcional)</span>
                                    </label>
                                    <input type="text" id="ruc_rut" name="ruc_rut" value="<?php echo e(old('ruc_rut')); ?>"
                                        class="form-control <?php $__errorArgs = ['ruc_rut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        maxlength="50" placeholder="RUC o RUT del cliente">
                                    <?php $__errorArgs = ['ruc_rut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-12 col-md-6">
                                    <label for="telefono" class="form-label fw-semibold">
                                        Teléfono <span class="text-secondary fw-normal">(opcional)</span>
                                    </label>
                                    <input type="tel" id="telefono" name="telefono" value="<?php echo e(old('telefono')); ?>"
                                        class="form-control <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Ej.: +55 11 99999-9999"
                                        autocomplete="tel" maxlength="50">
                                    <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <div class="form-text">Puede ser un teléfono fijo o celular.</div>
                                </div>

                                <div class="col-12 col-md-6">
                                    <label for="contacto_nombre" class="form-label fw-semibold">
                                        Nombre de contacto <span class="text-secondary fw-normal">(opcional)</span>
                                    </label>
                                    <input type="text" id="contacto_nombre" name="contacto_nombre"
                                        value="<?php echo e(old('contacto_nombre')); ?>"
                                        class="form-control <?php $__errorArgs = ['contacto_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        maxlength="255" placeholder="Persona de contacto">
                                    <?php $__errorArgs = ['contacto_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-12 col-md-6">
                                    <label for="contacto_email" class="form-label fw-semibold">
                                        Correo de contacto <span class="text-secondary fw-normal">(opcional)</span>
                                    </label>
                                    <input type="email" id="contacto_email" name="contacto_email"
                                        value="<?php echo e(old('contacto_email')); ?>"
                                        class="form-control <?php $__errorArgs = ['contacto_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        maxlength="255" placeholder="contacto@empresa.com">
                                    <?php $__errorArgs = ['contacto_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-12" data-solo-internacional hidden>
                                    <label for="despachante" class="form-label fw-semibold">
                                        Despachante <span class="text-secondary fw-normal">(opcional)</span>
                                    </label>
                                    <input type="text" id="despachante" name="despachante"
                                        value="<?php echo e(old('despachante')); ?>"
                                        class="form-control <?php $__errorArgs = ['despachante'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        maxlength="255" placeholder="Despachante habitual del cliente">
                                    <?php $__errorArgs = ['despachante'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-12">
                                    <label for="direccion" class="form-label fw-semibold">
                                        Dirección <span class="text-secondary fw-normal">(opcional)</span>
                                    </label>
                                    <input type="text" id="direccion" name="direccion"
                                        value="<?php echo e(old('direccion')); ?>"
                                        class="form-control <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Calle, número y ciudad" maxlength="255">
                                    <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-12">
                                    <hr>
                                    <h2 class="h5 fw-bold mb-0">Datos de acceso</h2>
                                    <p class="text-secondary mb-0 mt-2">
                                        Todos los clientes necesitan usuario y contraseña para consultar sus cargas.
                                        Las cuentas son creadas por personal autorizado.
                                    </p>
                                </div>

                                <div class="col-12">
                                    <label for="usuario" class="form-label fw-semibold">Usuario</label>
                                    <input type="text" id="usuario" name="usuario" value="<?php echo e(old('usuario')); ?>"
                                        class="form-control <?php $__errorArgs = ['usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Usuario para iniciar sesión"
                                        autocomplete="username"
                                        minlength="3" maxlength="255" required>
                                    <?php $__errorArgs = ['usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-12 col-md-6">
                                    <label for="password" class="form-label fw-semibold">Contraseña</label>
                                    <input type="password" id="password" name="password"
                                        class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        autocomplete="new-password"
                                        minlength="8" maxlength="255" required>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <div class="form-text">Debe contener al menos 8 caracteres.</div>
                                </div>

                                <div class="col-12 col-md-6">
                                    <label for="password_confirmation" class="form-label fw-semibold">
                                        Confirmar contraseña
                                    </label>
                                    <input type="password" id="password_confirmation"
                                        name="password_confirmation"
                                        class="form-control"
                                        autocomplete="new-password"
                                        minlength="8" maxlength="255" required>
                                </div>

                                <div class="col-12 d-flex flex-column flex-sm-row gap-2 justify-content-end">
                                    <a href="<?php echo e(route('panel.clientes.index')); ?>"
                                        class="btn btn-outline-secondary">Cancelar</a>
                                    <button type="submit" class="btn btn-warning fw-bold">
                                        <i class="bi bi-person-check-fill me-2"></i>
                                        Registrar cliente
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
            </div>
        </div>
    </main>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const origen = document.getElementById('origen');
        const descripcion = document.getElementById('descripcion-cliente');
        const aviso = document.getElementById('aviso-cliente');

        function actualizarCampos() {
            const nacional = origen.value === 'local';
            const internacional = origen.value === 'brasil' || origen.value === 'argentina';

            document.querySelectorAll('[data-solo-nacional]').forEach(function(elemento) {
                elemento.hidden = !nacional;

                elemento.querySelectorAll('input').forEach(function(campo) {
                    campo.disabled = !nacional;
                });
            });

            document.querySelectorAll('[data-solo-internacional]').forEach(function(elemento) {
                elemento.hidden = !internacional;

                elemento.querySelectorAll('input').forEach(function(campo) {
                    campo.disabled = !internacional;
                });
            });

            if (nacional || internacional) {
                descripcion.textContent = 'Registrá la empresa y creá sus credenciales para consultar las cargas.';
                aviso.textContent = 'Los clientes de Uruguay, Brasil y Argentina pueden acceder al portal. Las cuentas son creadas por personal autorizado de Translogística.';
            } else {
                descripcion.textContent = 'Seleccioná el país para registrar un cliente nacional o internacional.';
                aviso.textContent = 'Seleccioná Uruguay, Brasil o Argentina para completar los datos del cliente y sus credenciales.';
            }
        }

        origen.addEventListener('change', actualizarCampos);
        actualizarCampos();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Fefog\Desktop\Proyecto-Final\Translogistica\resources\views\panel\clientes\create.blade.php ENDPATH**/ ?>