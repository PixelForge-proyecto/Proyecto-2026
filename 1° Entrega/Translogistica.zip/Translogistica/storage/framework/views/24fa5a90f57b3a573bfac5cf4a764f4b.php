<?php $__env->startSection('title', 'Inicio | Translogística'); ?>

<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-expand-lg navbar-dark tl-navbar sticky-top">
        <div class="container">
            <a class="navbar-brand logo-container" href="#inicio">
                <img src="<?php echo e(asset('images/logo-translogistica.png')); ?>" alt="Translogística" class="navbar-logo">
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menuPrincipal"
                aria-controls="menuPrincipal" aria-expanded="false" aria-label="Abrir menú">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="menuPrincipal">
                <ul class="navbar-nav ms-auto align-items-lg-center">
                    <li class="nav-item">
                        <a class="nav-link active" href="#inicio">
                            Inicio
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="#servicios">
                            Servicios
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="#proceso">
                            Proceso
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="#contacto">
                            Contacto
                        </a>
                    </li>

                    <li class="nav-item ms-lg-3">
                        <a class="btn btn-tl-primary" href="<?php echo e(route('login')); ?>">
                            <i class="bi bi-person-fill me-2"></i>
                            Iniciar sesión
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <main>
        
        <section id="inicio" class="tl-hero"
            style="--tl-hero-image: url('<?php echo e(asset('images/camion-hero-banner.png')); ?>');">
            <div class="container">
                <div class="tl-hero-content">
                    <p class="tl-hero-kicker">
                        ASESORAMIENTO Y REPRESENTACIÓN
                    </p>

                    <h1>
                        Logística terrestre
                        <span class="highlight">
                            sin fronteras
                        </span>
                    </h1>

                    <p class="lead">
                        Conectamos los centros productivos de Uruguay,
                        Argentina y Brasil para optimizar operaciones de
                        importación y exportación de manera confiable,
                        segura y ágil.
                    </p>

                    <div class="tl-hero-actions">
                        <a href="#servicios" class="btn btn-tl-primary">
                            Conocer nuestros servicios
                        </a>

                        <a href="#contacto" class="btn btn-tl-outline">
                            Contactanos
                        </a>
                    </div>
                </div>
            </div>
        </section>

        
        <section class="tl-feature-strip">
            <div class="container">
                <div class="row g-0">
                    <div class="col-12 col-lg-4 tl-feature-item">
                        <div class="tl-feature-icon">
                            <i class="bi bi-geo-alt-fill"></i>
                        </div>

                        <div>
                            <strong>
                                Cobertura regional
                            </strong>

                            <span>
                                Uruguay, Argentina y Brasil
                            </span>
                        </div>
                    </div>

                    <div class="col-12 col-lg-4 tl-feature-item">
                        <div class="tl-feature-icon">
                            <i class="bi bi-shield-check"></i>
                        </div>

                        <div>
                            <strong>
                                Operaciones seguras
                            </strong>

                            <span>
                                Control logístico y documental
                            </span>
                        </div>
                    </div>

                    <div class="col-12 col-lg-4 tl-feature-item">
                        <div class="tl-feature-icon">
                            <i class="bi bi-search"></i>
                        </div>

                        <div>
                            <strong>
                                Seguimiento en línea
                            </strong>

                            <span>
                                Información actualizada de cada carga
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        
        <section id="servicios" class="section section-soft">
            <div class="container">
                <h2 class="section-title">
                    Servicios logísticos
                </h2>

                <div class="tl-accent-line"></div>

                <p class="section-subtitle">
                    Soluciones de transporte internacional terrestre
                    adaptadas a las características de cada operación.
                </p>

                <div class="row g-4">
                    <div class="col-12 col-md-6 col-lg-4">
                        <article class="tl-service-card">
                            <div class="tl-service-icon">
                                <i class="bi bi-people-fill"></i>
                            </div>

                            <h3>
                                Alianzas estratégicas
                            </h3>

                            <p>
                                Trabajamos con empresas de transporte de
                                Uruguay, Argentina y Brasil para seleccionar
                                la solución adecuada para cada operación.
                            </p>
                        </article>
                    </div>

                    <div class="col-12 col-md-6 col-lg-4">
                        <article class="tl-service-card">
                            <div class="tl-service-icon">
                                <i class="bi bi-file-earmark-text-fill"></i>
                            </div>

                            <h3>
                                Propuestas a medida
                            </h3>

                            <p>
                                Preparamos cotizaciones de transporte
                                internacional según el tipo, volumen y
                                necesidades particulares de cada carga.
                            </p>
                        </article>
                    </div>

                    <div class="col-12 col-md-6 col-lg-4">
                        <article class="tl-service-card">
                            <div class="tl-service-icon">
                                <i class="bi bi-signpost-split-fill"></i>
                            </div>

                            <h3>
                                Coordinación fronteriza
                            </h3>

                            <p>
                                Coordinamos la documentación y los trámites
                                necesarios para el paso de la mercadería
                                por frontera.
                            </p>
                        </article>
                    </div>

                    <div class="col-12 col-md-6 col-lg-4">
                        <article class="tl-service-card">
                            <div class="tl-service-icon">
                                <i class="bi bi-truck-front-fill"></i>
                            </div>

                            <h3>
                                Carga general
                            </h3>

                            <p>
                                Siders y semirremolques para mercadería
                                general, estibada y paletizada.
                            </p>
                        </article>
                    </div>

                    <div class="col-12 col-md-6 col-lg-4">
                        <article class="tl-service-card">
                            <div class="tl-service-icon">
                                <i class="bi bi-snow2"></i>
                            </div>

                            <h3>
                                Carga refrigerada
                            </h3>

                            <p>
                                Furgones y equipos frigoríficos para
                                productos que requieren protección o
                                control de temperatura.
                            </p>
                        </article>
                    </div>

                    <div class="col-12 col-md-6 col-lg-4">
                        <article class="tl-service-card">
                            <div class="tl-service-icon">
                                <i class="bi bi-box-seam-fill"></i>
                            </div>

                            <h3>
                                Cargas especiales
                            </h3>

                            <p>
                                Soluciones adaptadas a las características
                                y necesidades específicas de cada producto.
                            </p>
                        </article>
                    </div>
                </div>
            </div>
        </section>

        
        <section id="proceso" class="section tl-process">
            <div class="container">
                <h2 class="section-title">
                    Seguimiento de la operación
                </h2>

                <div class="tl-accent-line"></div>

                <p class="section-subtitle">
                    Cada carga se actualiza durante las distintas etapas
                    del proceso logístico.
                </p>

                <div class="row g-4 justify-content-center">
                    <div class="col-12 col-sm-6 col-lg">
                        <article class="tl-step">
                            <div class="tl-step-circle">
                                <i class="bi bi-box-seam"></i>

                                <span class="tl-step-number">
                                    1
                                </span>
                            </div>

                            <div class="tl-step-line"></div>

                            <h4>
                                Carga
                            </h4>

                            <p>
                                Registro del inicio de la operación.
                            </p>
                        </article>
                    </div>

                    <div class="col-12 col-sm-6 col-lg">
                        <article class="tl-step">
                            <div class="tl-step-circle">
                                <i class="bi bi-building"></i>

                                <span class="tl-step-number">
                                    2
                                </span>
                            </div>

                            <div class="tl-step-line"></div>

                            <h4>
                                Depósito
                            </h4>

                            <p>
                                Llegada y control de la mercadería.
                            </p>
                        </article>
                    </div>

                    <div class="col-12 col-sm-6 col-lg">
                        <article class="tl-step">
                            <div class="tl-step-circle">
                                <i class="bi bi-signpost-split"></i>

                                <span class="tl-step-number">
                                    3
                                </span>
                            </div>

                            <div class="tl-step-line"></div>

                            <h4>
                                Frontera
                            </h4>

                            <p>
                                Control y asignación del canal aduanero.
                            </p>
                        </article>
                    </div>

                    <div class="col-12 col-sm-6 col-lg">
                        <article class="tl-step">
                            <div class="tl-step-circle">
                                <i class="bi bi-shield-check"></i>

                                <span class="tl-step-number">
                                    4
                                </span>
                            </div>

                            <div class="tl-step-line"></div>

                            <h4>
                                Liberación
                            </h4>

                            <p>
                                Autorización para continuar el traslado.
                            </p>
                        </article>
                    </div>

                    <div class="col-12 col-sm-6 col-lg">
                        <article class="tl-step">
                            <div class="tl-step-circle">
                                <i class="bi bi-check-circle"></i>

                                <span class="tl-step-number">
                                    5
                                </span>
                            </div>

                            <h4>
                                Entrega
                            </h4>

                            <p>
                                Finalización de la operación.
                            </p>
                        </article>
                    </div>
                </div>
            </div>
        </section>

        
        <section id="contacto" class="section tl-contact-section">
            <div class="container">
                <h2 class="section-title">
                    Contacto
                </h2>

                <div class="tl-accent-line"></div>

                <p class="section-subtitle">
                    Comunicate con Translogística para realizar una consulta
                    sobre nuestros servicios.
                </p>

                <div class="row g-3 justify-content-center">
                    
                    <div class="col-12 col-md-6 col-lg-5">
                        <a href="https://wa.me/59897079999" class="tl-contact-card text-decoration-none" target="_blank"
                            rel="noopener noreferrer" aria-label="Contactar a Translogística por WhatsApp">
                            <div class="tl-contact-icon">
                                <i class="bi bi-whatsapp" aria-hidden="true"></i>
                            </div>

                            <div>
                                <h4>
                                    WhatsApp
                                </h4>

                                <p>
                                    +598 97 079 999
                                </p>
                            </div>
                        </a>
                    </div>

                    
                    <div class="col-12 col-md-6 col-lg-5">
                        <a href="mailto:enrique@translogistica.com.uy" class="tl-contact-card text-decoration-none"
                            aria-label="Enviar un correo electrónico a Translogística">
                            <div class="tl-contact-icon">
                                <i class="bi bi-envelope" aria-hidden="true"></i>
                            </div>

                            <div>
                                <h4>
                                    Correo electrónico
                                </h4>

                                <p>
                                    enrique@translogistica.com.uy
                                </p>
                            </div>
                        </a>
                    </div>

                    
                    <div class="col-12 col-md-6 col-lg-5">
                        <div class="tl-contact-card">
                            <div class="tl-contact-icon">
                                <i class="bi bi-clock" aria-hidden="true"></i>
                            </div>

                            <div>
                                <h4>
                                    Horario de atención
                                </h4>

                                <p>
                                    Lunes a viernes de 08:00 a 19:00
                                    <br>
                                    Sábados de 09:00 a 14:00
                                </p>
                            </div>
                        </div>
                    </div>

                    
                    <div class="col-12 col-md-6 col-lg-5">
                        <a href="https://www.google.com/maps/place/Jaime+Rold%C3%B3s+y+Pons+4189,+12000+Montevideo,+Departamento+de+Montevideo/@-34.8567223,-56.153127,15z/data=!4m16!1m9!3m8!1s0x959f808187cf19fd:0xa952dd3844b08b23!2sJaime+Rold%C3%B3s+y+Pons+4189,+12000+Montevideo,+Departamento+de+Montevideo!3b1!8m2!3d-34.8565993!4d-56.1533874!10e5!16s%2Fg%2F11vls2zh64!3m5!1s0x959f808187cf19fd:0xa952dd3844b08b23!8m2!3d-34.8565993!4d-56.1533874!16s%2Fg%2F11vls2zh64?entry=ttu&g_ep=EgoyMDI2MTAxOC4wIKXMDSoASAFQAw%3D%3D"
                            class="tl-contact-card text-decoration-none" target="_blank" rel="noopener noreferrer"
                            aria-label="Abrir ubicación de Translogística en Google Maps">
                            <div class="tl-contact-icon">
                                <i class="bi bi-geo-alt" aria-hidden="true"></i>
                            </div>

                            <div>
                                <h4>
                                    Ubicación
                                </h4>

                                <p>
                                    Calle y número, Montevideo, Uruguay
                                </p>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <footer class="tl-footer">
        <div class="container">
            <p class="mb-1">
                <strong>
                    Translogística
                </strong>
            </p>

            <p class="mb-1">
                Uruguay · Argentina · Brasil
            </p>

            <p class="small mb-0">
                © <?php echo e(date('Y')); ?> Translogística.
                Todos los derechos reservados.
            </p>
        </div>
    </footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Fefog\Desktop\Proyecto-Final\Translogistica\resources\views\welcome.blade.php ENDPATH**/ ?>