<?php $__env->startSection('title', 'Actualizar seguimiento | Translogística'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-vh-100 bg-light">
    <?php if (isset($component)) { $__componentOriginalbe062454937ca58204f074f7f20cd3ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbe062454937ca58204f074f7f20cd3ac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.panel-navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('panel-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbe062454937ca58204f074f7f20cd3ac)): ?>
<?php $attributes = $__attributesOriginalbe062454937ca58204f074f7f20cd3ac; ?>
<?php unset($__attributesOriginalbe062454937ca58204f074f7f20cd3ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbe062454937ca58204f074f7f20cd3ac)): ?>
<?php $component = $__componentOriginalbe062454937ca58204f074f7f20cd3ac; ?>
<?php unset($__componentOriginalbe062454937ca58204f074f7f20cd3ac); ?>
<?php endif; ?>

    <main class="container py-5">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-8">
                <div class="mb-4">
                    <a
                        href="<?php echo e(route('panel.seguimientos.index')); ?>"
                        class="text-decoration-none">
                        <i class="bi bi-arrow-left me-1"></i>
                        Volver a seguimientos
                    </a>
                </div>

                <section class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-dark text-white py-3">
                        <h1 class="h4 mb-0">
                            Actualizar seguimiento
                        </h1>
                    </div>

                    <div class="card-body">
                        <div class="row g-4">
                            <div class="col-12 col-md-4">
                                <span class="text-secondary d-block">
                                    Número de ficha
                                </span>

                                <strong>
                                    <?php echo e($datos['numero']); ?>

                                </strong>
                            </div>

                            <div class="col-12 col-md-4">
                                <span class="text-secondary d-block">
                                    CRT
                                </span>

                                <strong>
                                    <?php echo e($datos['crt']); ?>

                                </strong>
                            </div>

                            <div class="col-12 col-md-4">
                                <span class="text-secondary d-block">
                                    Cliente
                                </span>

                                <strong>
                                    <?php echo e($datos['cliente']); ?>

                                </strong>
                            </div>
                        </div>
                    </div>
                </section>

                <section class="card border-0 shadow-sm">
                    <div class="card-body p-4 p-md-5">
                        <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                        <?php endif; ?>

                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger" role="alert">
                            <p class="fw-bold mb-2">
                                Revisá los datos ingresados:
                            </p>

                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <form
                            method="POST"
                            action="<?php echo e(route('panel.seguimientos.update', $seguimiento)); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="row g-4">
                                <div class="col-12 col-md-6">
                                    <label
                                        for="etapa"
                                        class="form-label fw-semibold">
                                        Etapa
                                    </label>

                                    <select
                                        id="etapa"
                                        name="etapa"
                                        class="form-select <?php $__errorArgs = ['etapa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option value="">
                                            Sin etapa
                                        </option>

                                        <option
                                            value="carga"
                                            <?php if(
                                            old( 'etapa' ,
                                            $datos['etapa_valor']
                                            )==='carga'
                                            ): echo 'selected'; endif; ?>>
                                            Carga
                                        </option>

                                        <option
                                            value="deposito"
                                            <?php if(
                                            old( 'etapa' ,
                                            $datos['etapa_valor']
                                            )==='deposito'
                                            ): echo 'selected'; endif; ?>>
                                            Depósito
                                        </option>

                                        <option
                                            value="frontera"
                                            <?php if(
                                            old( 'etapa' ,
                                            $datos['etapa_valor']
                                            )==='frontera'
                                            ): echo 'selected'; endif; ?>>
                                            Frontera
                                        </option>

                                        <option
                                            value="aduana_internacional"
                                            <?php if(
                                            old( 'etapa' ,
                                            $datos['etapa_valor']
                                            )==='aduana_internacional'
                                            ): echo 'selected'; endif; ?>>
                                            Aduana internacional
                                        </option>

                                        <option
                                            value="aduana_nacional"
                                            <?php if(
                                            old( 'etapa' ,
                                            $datos['etapa_valor']
                                            )==='aduana_nacional'
                                            ): echo 'selected'; endif; ?>>
                                            Aduana nacional
                                        </option>

                                        <option
                                            value="liberacion"
                                            <?php if(
                                            old( 'etapa' ,
                                            $datos['etapa_valor']
                                            )==='liberacion'
                                            ): echo 'selected'; endif; ?>>
                                            Liberación
                                        </option>

                                        <option
                                            value="entrega"
                                            <?php if(
                                            old( 'etapa' ,
                                            $datos['etapa_valor']
                                            )==='entrega'
                                            ): echo 'selected'; endif; ?>>
                                            Entrega
                                        </option>
                                    </select>

                                    <?php $__errorArgs = ['etapa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <div class="form-text">
                                        Al seleccionar una etapa registrada,
                                        se cargarán sus datos automáticamente.
                                        Si la etapa aún no existe, los campos
                                        quedarán vacíos.
                                    </div>
                                </div>

                                <div class="col-12 col-md-6">
                                    <label
                                        for="fecha"
                                        class="form-label fw-semibold">
                                        Fecha
                                    </label>

                                    <input
                                        type="date"
                                        id="fecha"
                                        name="fecha"
                                        value="<?php echo e(old('fecha', $datos['fecha'])); ?>"
                                        class="form-control <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                    <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <div class="form-text">
                                        La fecha es obligatoria cuando se
                                        selecciona una etapa.
                                    </div>
                                </div>

                                <div class="col-12">
                                    <label
                                        for="canal_aduanero"
                                        class="form-label fw-semibold">
                                        Canal aduanero
                                    </label>

                                    <select
                                        id="canal_aduanero"
                                        name="canal_aduanero"
                                        class="form-select <?php $__errorArgs = ['canal_aduanero'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option value="">
                                            Sin asignar
                                        </option>

                                        <option
                                            value="verde"
                                            <?php if(
                                            old( 'canal_aduanero' ,
                                            $datos['canal_aduanero']
                                            )==='verde'
                                            ): echo 'selected'; endif; ?>>
                                            Verde
                                        </option>

                                        <option
                                            value="naranja"
                                            <?php if(
                                            old( 'canal_aduanero' ,
                                            $datos['canal_aduanero']
                                            )==='naranja'
                                            ): echo 'selected'; endif; ?>>
                                            Naranja
                                        </option>

                                        <option
                                            value="rojo"
                                            <?php if(
                                            old( 'canal_aduanero' ,
                                            $datos['canal_aduanero']
                                            )==='rojo'
                                            ): echo 'selected'; endif; ?>>
                                            Rojo
                                        </option>
                                    </select>

                                    <?php $__errorArgs = ['canal_aduanero'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <div class="form-text">
                                        Campo opcional. Solo se habilita
                                        para Aduana internacional y
                                        Aduana nacional.
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="alert alert-secondary mb-0">
                                        <strong>Verde:</strong>
                                        mercadería liberada.

                                        <br>

                                        <strong>Naranja:</strong>
                                        inspección documental.

                                        <br>

                                        <strong>Rojo:</strong>
                                        inspección física de la mercadería.
                                    </div>
                                </div>

                                <div class="col-12">
                                    <label
                                        for="observacion"
                                        class="form-label fw-semibold">
                                        Observaciones
                                    </label>

                                    <textarea
                                        id="observacion"
                                        name="observacion"
                                        class="form-control <?php $__errorArgs = ['observacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        rows="4"
                                        maxlength="2000"
                                        placeholder="Ingresá novedades u observaciones."><?php echo e(old('observacion', $datos['observacion'])); ?></textarea>

                                    <?php $__errorArgs = ['observacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <div class="form-text">
                                        Se puede registrar una observación
                                        sin etapa ni fecha.
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="form-check">
                                        <input
                                            type="checkbox"
                                            id="notificar_cliente"
                                            name="notificar_cliente"
                                            class="form-check-input <?php $__errorArgs = ['notificar_cliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="1"
                                            <?php if(
                                            session()->hasOldInput()
                                        ? old('notificar_cliente')
                                        : $datos['notificar_cliente']
                                        ): echo 'checked'; endif; ?>
                                        >

                                        <label
                                            for="notificar_cliente"
                                            class="form-check-label">
                                            Notificar al cliente sobre esta
                                            actualización
                                        </label>

                                        <?php $__errorArgs = ['notificar_cliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-12 d-flex flex-column flex-sm-row justify-content-end gap-2">
                                    <a
                                        href="<?php echo e(route('panel.seguimientos.show', $seguimiento)); ?>"
                                        class="btn btn-outline-secondary">
                                        Cancelar
                                    </a>

                                    <button
                                        type="submit"
                                        class="btn btn-warning fw-bold">
                                        <i class="bi bi-check-circle-fill me-2"></i>
                                        Guardar actualización
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
            </div>
        </div>
    </main>
</div>

<script type="application/json" id="datos-etapas-seguimiento">
    <?php echo json_encode($datosEtapas ?? [], 15, 512) ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Fefog\Desktop\Proyecto-Final\Translogistica\resources\views\panel\seguimientos\edit.blade.php ENDPATH**/ ?>