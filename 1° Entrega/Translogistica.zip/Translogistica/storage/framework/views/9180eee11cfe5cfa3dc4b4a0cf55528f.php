<nav class="navbar navbar-expand-lg navbar-dark tl-navbar shadow-sm">
    <div class="container">
        <a
            class="navbar-brand bg-white rounded-2 px-2 py-1"
            href="<?php echo e(route('cliente.inicio')); ?>"
            aria-label="Ir al inicio de Translogística">
            <img
                src="<?php echo e(asset('images/logo-translogistica.png')); ?>"
                alt="Translogística">
        </a>

        <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#clienteNavegacion"
            aria-controls="clienteNavegacion"
            aria-expanded="false"
            aria-label="Mostrar navegación">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div
            class="collapse navbar-collapse"
            id="clienteNavegacion">
            <ul
                class="navbar-nav ms-auto
                    align-items-lg-center gap-lg-1">
                <li class="nav-item">
                    <a
                        class="nav-link
                            <?php echo e(request()->routeIs('cliente.inicio') ? 'active' : ''); ?>"
                        href="<?php echo e(route('cliente.inicio')); ?>"
                        <?php if(request()->routeIs('cliente.inicio')): ?>
                        aria-current="page"
                        <?php endif; ?>
                        >
                        <i
                            class="bi bi-house-door me-1"
                            aria-hidden="true"></i>

                        Inicio
                    </a>
                </li>

                <li class="nav-item">
                    <a
                        class="nav-link
                            <?php echo e(request()->routeIs('cliente.cargas.*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('cliente.cargas.index')); ?>"
                        <?php if(request()->routeIs('cliente.cargas.*')): ?>
                        aria-current="page"
                        <?php endif; ?>
                        >
                        <i
                            class="bi bi-box-seam me-1"
                            aria-hidden="true"></i>

                        Mis cargas
                    </a>
                </li>

                <li
                    class="nav-item ms-lg-3
                        ps-lg-3 border-start border-secondary">
                    <form
                        method="POST"
                        action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>

                        <button
                            type="submit"
                            class="btn btn-outline-warning
                                fw-semibold w-100">
                            <i
                                class="bi bi-box-arrow-right me-1"
                                aria-hidden="true"></i>

                            Salir
                        </button>
                    </form>
                </li>
            </ul>
        </div>
    </div>
</nav><?php /**PATH C:\Users\Fefog\Desktop\Proyecto-Final\Translogistica\resources\views\components\cliente-navbar.blade.php ENDPATH**/ ?>