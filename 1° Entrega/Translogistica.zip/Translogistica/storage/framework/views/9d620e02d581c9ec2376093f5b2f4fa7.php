<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['codigo', 'titulo', 'mensaje', 'icono' => 'bi-exclamation-triangle-fill']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['codigo', 'titulo', 'mensaje', 'icono' => 'bi-exclamation-triangle-fill']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    if (auth('interno')->check()) {
        $rutaRegreso = route('panel.dashboard');
        $textoRegreso = 'Volver al panel';
    } elseif (auth('cliente')->check()) {
        $rutaRegreso = route('cliente.inicio');
        $textoRegreso = 'Volver al área del cliente';
    } else {
        $rutaRegreso = url('/');
        $textoRegreso = 'Volver al inicio';
    }
?>

<div class="min-vh-100 bg-light d-flex align-items-center">
    <main class="container py-5">
        <div class="row justify-content-center">
            <div class="col-12 col-md-8 col-lg-6">
                <section class="card border-0 shadow-sm text-center">
                    <div class="card-body p-4 p-md-5">
                        <i class="bi <?php echo e($icono); ?> display-1 text-warning" aria-hidden="true"></i>

                        <p class="display-3 fw-bold mb-2">
                            <?php echo e($codigo); ?>

                        </p>

                        <h1 class="h3 fw-bold mb-3">
                            <?php echo e($titulo); ?>

                        </h1>

                        <p class="text-secondary mb-4">
                            <?php echo e($mensaje); ?>

                        </p>

                        <a href="<?php echo e($rutaRegreso); ?>" class="btn btn-dark fw-semibold">
                            <i class="bi bi-arrow-left me-2"></i>
                            <?php echo e($textoRegreso); ?>

                        </a>
                    </div>
                </section>
            </div>
        </div>
    </main>
</div>
<?php /**PATH C:\Users\Fefog\Desktop\Proyecto-Final\Translogistica\resources\views\components\error-page.blade.php ENDPATH**/ ?>