

<?php $__env->startSection('title', 'Nuevo despachante local | Translogística'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-vh-100 bg-light">
    <?php if (isset($component)) { $__componentOriginalbe062454937ca58204f074f7f20cd3ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbe062454937ca58204f074f7f20cd3ac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.panel-navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('panel-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbe062454937ca58204f074f7f20cd3ac)): ?>
<?php $attributes = $__attributesOriginalbe062454937ca58204f074f7f20cd3ac; ?>
<?php unset($__attributesOriginalbe062454937ca58204f074f7f20cd3ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbe062454937ca58204f074f7f20cd3ac)): ?>
<?php $component = $__componentOriginalbe062454937ca58204f074f7f20cd3ac; ?>
<?php unset($__componentOriginalbe062454937ca58204f074f7f20cd3ac); ?>
<?php endif; ?>

    <main class="container py-5">
        <div class="mb-4">
            <a href="<?php echo e(route('panel.despachantes.index')); ?>" class="text-decoration-none text-secondary">
                <i class="bi bi-arrow-left me-1"></i>
                Volver a despachantes locales
            </a>
        </div>

        <div class="mb-4">
            <h1 class="fw-bold mb-1">
                Nuevo despachante local
            </h1>

            <p class="text-secondary mb-0">
                Ingresá los datos del despachante de aduana de Uruguay
                que podrá ser seleccionado en las fichas.
            </p>
        </div>

        <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>

        <section class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <form method="POST" action="<?php echo e(route('panel.despachantes.store')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="row g-4">
                        <div class="col-12">
                            <label for="nombre" class="form-label fw-semibold">
                                Nombre del despachante
                            </label>

                            <input type="text" id="nombre" name="nombre"
                                value="<?php echo e(old('nombre')); ?>"
                                class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                maxlength="255" required>

                            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-12 col-md-6">
                            <label for="email" class="form-label fw-semibold">
                                Correo electrónico
                            </label>

                            <input type="email" id="email" name="email"
                                value="<?php echo e(old('email')); ?>"
                                class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                maxlength="255"
                                placeholder="Ejemplo: contacto@despachante.com">

                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div class="form-text">
                                Campo opcional.
                            </div>
                        </div>

                        <div class="col-12 col-md-6">
                            <label for="telefono" class="form-label fw-semibold">
                                Teléfono del despachante
                            </label>

                            <input type="text" id="telefono" name="telefono"
                                value="<?php echo e(old('telefono')); ?>"
                                class="form-control <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                maxlength="50"
                                placeholder="Ejemplo: 2900 0000">

                            <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div class="form-text">
                                Campo opcional.
                            </div>
                        </div>

                        <div class="col-12">
                            <label for="direccion" class="form-label fw-semibold">
                                Dirección
                            </label>

                            <input type="text" id="direccion" name="direccion"
                                value="<?php echo e(old('direccion')); ?>"
                                class="form-control <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                maxlength="255"
                                placeholder="Ejemplo: Av. 18 de Julio 1234, Montevideo">

                            <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div class="form-text">
                                Campo opcional.
                            </div>
                        </div>

                        <div class="col-12 col-md-6">
                            <label for="gestor" class="form-label fw-semibold">
                                Gestor
                            </label>

                            <input type="text" id="gestor" name="gestor"
                                value="<?php echo e(old('gestor')); ?>"
                                class="form-control <?php $__errorArgs = ['gestor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                maxlength="255"
                                placeholder="Nombre del gestor">

                            <?php $__errorArgs = ['gestor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div class="form-text">
                                Campo opcional.
                            </div>
                        </div>

                        <div class="col-12 col-md-6">
                            <label for="gestor_telefono" class="form-label fw-semibold">
                                Teléfono del gestor
                            </label>

                            <input type="text" id="gestor_telefono" name="gestor_telefono"
                                value="<?php echo e(old('gestor_telefono')); ?>"
                                class="form-control <?php $__errorArgs = ['gestor_telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                maxlength="50"
                                placeholder="Ejemplo: 099 123 456">

                            <?php $__errorArgs = ['gestor_telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div class="form-text">
                                Campo opcional.
                            </div>
                        </div>

                        <div class="col-12">
                            <label for="contacto" class="form-label fw-semibold">
                                Contacto
                            </label>

                            <input type="text" id="contacto" name="contacto"
                                value="<?php echo e(old('contacto')); ?>"
                                class="form-control <?php $__errorArgs = ['contacto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                maxlength="255"
                                placeholder="Nombre o información de contacto adicional">

                            <?php $__errorArgs = ['contacto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div class="form-text">
                                Campo opcional.
                            </div>
                        </div>
                    </div>

                    <div class="d-flex flex-column flex-sm-row justify-content-end gap-2 mt-4">
                        <a href="<?php echo e(route('panel.despachantes.index')); ?>"
                            class="btn btn-outline-secondary">
                            Cancelar
                        </a>

                        <button type="submit" class="btn btn-warning fw-bold">
                            <i class="bi bi-check-circle me-2"></i>
                            Registrar despachante
                        </button>
                    </div>
                </form>
            </div>
        </section>
    </main>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Fefog\Desktop\Proyecto-Final\Translogistica\resources\views\panel\despachantes\create.blade.php ENDPATH**/ ?>