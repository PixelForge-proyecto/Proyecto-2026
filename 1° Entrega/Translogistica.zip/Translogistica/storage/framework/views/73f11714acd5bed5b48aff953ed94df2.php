<?php $__env->startSection('title', 'Detalle del cliente | Translogística'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-vh-100 bg-light">
    <?php if (isset($component)) { $__componentOriginalbe062454937ca58204f074f7f20cd3ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbe062454937ca58204f074f7f20cd3ac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.panel-navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('panel-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbe062454937ca58204f074f7f20cd3ac)): ?>
<?php $attributes = $__attributesOriginalbe062454937ca58204f074f7f20cd3ac; ?>
<?php unset($__attributesOriginalbe062454937ca58204f074f7f20cd3ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbe062454937ca58204f074f7f20cd3ac)): ?>
<?php $component = $__componentOriginalbe062454937ca58204f074f7f20cd3ac; ?>
<?php unset($__componentOriginalbe062454937ca58204f074f7f20cd3ac); ?>
<?php endif; ?>

    <main class="container py-5">
        <?php if(session('status')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('status')); ?>


            <button type="button" class="btn-close" data-bs-dismiss="alert"
                aria-label="Cerrar"></button>
        </div>
        <?php endif; ?>

        <div class="mb-4">
            <a href="<?php echo e(route('panel.clientes.index')); ?>"
                class="text-decoration-none">
                <i class="bi bi-arrow-left me-1"></i>
                Volver a clientes
            </a>
        </div>

        <div
            class="d-flex flex-column flex-md-row
                justify-content-between align-items-md-center
                gap-3 mb-4">
            <div>
                <h1 class="fw-bold mb-1">
                    Detalle del cliente
                </h1>

                <p class="text-secondary mb-0">
                    Información registrada del cliente.
                </p>
            </div>

            <a href="<?php echo e(route('panel.clientes.edit', $cliente)); ?>"
                class="btn btn-warning fw-bold">
                <i class="bi bi-pencil-square me-2"></i>
                Editar cliente
            </a>
        </div>

        <section class="card border-0 shadow-sm">
            <div class="card-header bg-dark text-white py-3">
                <h2 class="h5 mb-0">
                    <?php echo e($cliente->nombre); ?>

                </h2>
            </div>

            <div class="card-body p-4">
                <div class="row g-4">

                    
                    <div class="col-12 col-md-6">
                        <span class="text-secondary d-block">
                            Nombre
                        </span>

                        <strong>
                            <?php echo e($cliente->nombre); ?>

                        </strong>
                    </div>

                    
                    <div class="col-12 col-md-6">
                        <span class="text-secondary d-block">
                            País de origen
                        </span>

                        <strong>
                            <?php switch($cliente->origen):
                            case ('local'): ?>
                            Uruguay
                            <?php break; ?>

                            <?php case ('brasil'): ?>
                            Brasil
                            <?php break; ?>

                            <?php case ('argentina'): ?>
                            Argentina
                            <?php break; ?>

                            <?php default: ?>
                            <?php echo e(ucfirst($cliente->origen ?? '')); ?>

                            <?php endswitch; ?>
                        </strong>
                    </div>

                    
                    <div class="col-12 col-md-6">
                        <span class="text-secondary d-block">
                            Estado
                        </span>

                        <?php if($cliente->estado === 'activo'): ?>
                        <span class="badge text-bg-success">
                            Activo
                        </span>
                        <?php else: ?>
                        <span class="badge text-bg-secondary">
                            Inactivo
                        </span>
                        <?php endif; ?>
                    </div>

                    
                    <?php if($cliente->esNacional()): ?>
                    <div class="col-12 col-md-6">
                        <span class="text-secondary d-block">
                            RUC/RUT
                        </span>

                        <strong>
                            <?php echo e($cliente->ruc_rut ?: 'Sin especificar'); ?>

                        </strong>
                    </div>
                    <?php endif; ?>

                    
                    <div class="col-12 col-md-6">
                        <span class="text-secondary d-block">
                            Contacto
                        </span>

                        <strong>
                            <?php echo e($cliente->contacto_nombre ?: 'Sin especificar'); ?>

                        </strong>
                    </div>

                    
                    <div class="col-12 col-md-6">
                        <span class="text-secondary d-block">
                            Email del contacto
                        </span>

                        <strong>
                            <?php echo e($cliente->contacto_email ?: 'Sin especificar'); ?>

                        </strong>
                    </div>

                    
                    <div class="col-12 col-md-6">
                        <span class="text-secondary d-block">
                            Teléfono
                        </span>

                        <strong>
                            <?php echo e($cliente->telefono ?: 'Sin especificar'); ?>

                        </strong>
                    </div>

                    
                    <div class="col-12 col-md-6">
                        <span class="text-secondary d-block">
                            Dirección
                        </span>

                        <strong>
                            <?php echo e($cliente->direccion ?: 'Sin especificar'); ?>

                        </strong>
                    </div>

                    
                    <?php if($cliente->esInternacional()): ?>
                    <div class="col-12 col-md-6">
                        <span class="text-secondary d-block">
                            Despachante
                        </span>

                        <strong>
                            <?php echo e($cliente->despachante ?: 'Sin especificar'); ?>

                        </strong>
                    </div>
                    <?php endif; ?>

                    
                    <?php if($cliente->esNacional()): ?>
                    <div class="col-12">
                        <hr>
                    </div>

                    <div class="col-12 col-md-6">
                        <span class="text-secondary d-block">
                            Usuario
                        </span>

                        <strong>
                            <?php echo e($cliente->usuario ?: 'Sin especificar'); ?>

                        </strong>
                    </div>

                    <div class="col-12">
                        <h3 class="h5 fw-bold">
                            Acceso del cliente
                        </h3>

                        <p class="text-secondary mb-0">
                            La contraseña se almacena de forma protegida
                            y no se muestra en esta pantalla.
                        </p>
                    </div>
                    <?php endif; ?>

                </div>
            </div>
        </section>
    </main>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Fefog\Desktop\Proyecto-Final\Translogistica\resources\views\panel\clientes\show.blade.php ENDPATH**/ ?>