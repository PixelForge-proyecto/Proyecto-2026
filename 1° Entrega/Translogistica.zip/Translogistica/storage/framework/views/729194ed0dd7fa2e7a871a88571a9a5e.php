

<?php $__env->startSection('title', 'Detalle del despachante local | Translogística'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-vh-100 bg-light">
    <?php if (isset($component)) { $__componentOriginalbe062454937ca58204f074f7f20cd3ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbe062454937ca58204f074f7f20cd3ac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.panel-navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('panel-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbe062454937ca58204f074f7f20cd3ac)): ?>
<?php $attributes = $__attributesOriginalbe062454937ca58204f074f7f20cd3ac; ?>
<?php unset($__attributesOriginalbe062454937ca58204f074f7f20cd3ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbe062454937ca58204f074f7f20cd3ac)): ?>
<?php $component = $__componentOriginalbe062454937ca58204f074f7f20cd3ac; ?>
<?php unset($__componentOriginalbe062454937ca58204f074f7f20cd3ac); ?>
<?php endif; ?>

    <main class="container py-5">
        <?php if(session('status')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('status')); ?>


            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
        </div>
        <?php endif; ?>

        <div class="mb-4">
            <a href="<?php echo e(route('panel.despachantes.index')); ?>" class="text-decoration-none">
                <i class="bi bi-arrow-left me-1"></i>
                Volver a despachantes locales
            </a>
        </div>

        <div
            class="d-flex flex-column flex-md-row
                    justify-content-between align-items-md-center
                    gap-3 mb-4">
            <div>
                <h1 class="fw-bold mb-1">
                    Detalle del despachante local
                </h1>

                <p class="text-secondary mb-0">
                    Información registrada para el despachante
                    de aduana seleccionado.
                </p>
            </div>

            <a href="<?php echo e(route('panel.despachantes.edit', $despachante)); ?>"
                class="btn btn-warning fw-bold">
                <i class="bi bi-pencil-square me-2"></i>
                Editar
            </a>
        </div>

        <section class="card border-0 shadow-sm">
            <div class="card-header bg-dark text-white py-3">
                <h2 class="h5 fw-bold mb-0">
                    <?php echo e($despachante->nombre); ?>

                </h2>
            </div>

            <div class="card-body p-4">
                <div class="row g-4">
                    <div class="col-12 col-md-6">
                        <p class="text-secondary mb-1">
                            Nombre del despachante
                        </p>

                        <p class="fw-semibold mb-0">
                            <?php echo e($despachante->nombre); ?>

                        </p>
                    </div>

                    <div class="col-12 col-md-6">
                        <p class="text-secondary mb-1">
                            Correo electrónico
                        </p>

                        <p class="fw-semibold mb-0">
                            <?php echo e($despachante->email ?: 'Sin especificar'); ?>

                        </p>
                    </div>

                    <div class="col-12 col-md-6">
                        <p class="text-secondary mb-1">
                            Teléfono del despachante
                        </p>

                        <p class="fw-semibold mb-0">
                            <?php echo e($despachante->telefono ?: 'Sin especificar'); ?>

                        </p>
                    </div>

                    <div class="col-12 col-md-6">
                        <p class="text-secondary mb-1">
                            Dirección
                        </p>

                        <p class="fw-semibold mb-0">
                            <?php echo e($despachante->direccion ?: 'Sin especificar'); ?>

                        </p>
                    </div>

                    <div class="col-12 col-md-6">
                        <p class="text-secondary mb-1">
                            Gestor
                        </p>

                        <p class="fw-semibold mb-0">
                            <?php echo e($despachante->gestor ?: 'Sin especificar'); ?>

                        </p>
                    </div>

                    <div class="col-12 col-md-6">
                        <p class="text-secondary mb-1">
                            Teléfono del gestor
                        </p>

                        <p class="fw-semibold mb-0">
                            <?php echo e($despachante->gestor_telefono ?: 'Sin especificar'); ?>

                        </p>
                    </div>

                    <div class="col-12 col-md-6">
                        <p class="text-secondary mb-1">
                            Contacto
                        </p>

                        <p class="fw-semibold mb-0">
                            <?php echo e($despachante->contacto ?: 'Sin especificar'); ?>

                        </p>
                    </div>

                    <div class="col-12 col-md-6">
                        <p class="text-secondary mb-1">
                            Estado
                        </p>

                        <span class="badge text-bg-success">
                            Activo
                        </span>
                    </div>
                </div>
            </div>
        </section>
    </main>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Fefog\Desktop\Proyecto-Final\Translogistica\resources\views\panel\despachantes\show.blade.php ENDPATH**/ ?>