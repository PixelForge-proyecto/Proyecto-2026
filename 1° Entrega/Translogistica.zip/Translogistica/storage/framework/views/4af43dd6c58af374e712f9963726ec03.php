<?php $__env->startSection('title', 'Fichas | Translogística'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-vh-100 bg-light">
    <?php if (isset($component)) { $__componentOriginalbe062454937ca58204f074f7f20cd3ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbe062454937ca58204f074f7f20cd3ac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.panel-navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('panel-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbe062454937ca58204f074f7f20cd3ac)): ?>
<?php $attributes = $__attributesOriginalbe062454937ca58204f074f7f20cd3ac; ?>
<?php unset($__attributesOriginalbe062454937ca58204f074f7f20cd3ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbe062454937ca58204f074f7f20cd3ac)): ?>
<?php $component = $__componentOriginalbe062454937ca58204f074f7f20cd3ac; ?>
<?php unset($__componentOriginalbe062454937ca58204f074f7f20cd3ac); ?>
<?php endif; ?>

    <main class="container py-5">
        <?php if(session('status')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('status')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
        </div>
        <?php endif; ?>

        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
            <div>
                <h1 class="fw-bold mb-1">Fichas</h1>
                <p class="text-secondary mb-0">Consulta y administración de operaciones de transporte.</p>
            </div>

            <a href="<?php echo e(route('panel.fichas.create')); ?>" class="btn btn-warning fw-bold">
                <i class="bi bi-file-earmark-plus-fill me-2"></i>
                Nueva ficha
            </a>
        </div>

        <section class="card border-0 shadow-sm mb-4">
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('panel.fichas.index')); ?>">
                    <div class="row g-3 align-items-end">
                        <div class="col-12 col-lg-9">
                            <label for="buscar-ficha" class="form-label fw-semibold">Buscar operación</label>
                            <input type="search" id="buscar-ficha" name="buscar" value="<?php echo e(request('buscar')); ?>"
                                class="form-control" placeholder="Número de ficha, CRT, DUA o cliente">
                        </div>
                        <div class="col-12 col-lg-3">
                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-dark flex-grow-1">
                                    <i class="bi bi-search me-2"></i>
                                    Buscar
                                </button>
                                <?php if(request()->filled('buscar')): ?>
                                <a href="<?php echo e(route('panel.fichas.index')); ?>" class="btn btn-outline-secondary"
                                    title="Limpiar búsqueda" aria-label="Limpiar búsqueda">
                                    <i class="bi bi-x-lg"></i>
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </section>

        <section class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h2 class="h5 fw-bold mb-0">Operaciones registradas</h2>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th scope="col">Ficha</th>
                            <th scope="col">CRT</th>
                            <th scope="col">Cliente nacional</th>
                            <th scope="col">Cliente internacional</th>
                            <th scope="col">Operación</th>
                            <th scope="col">Transportista</th>
                            <th scope="col">Estado</th>
                            <th scope="col">Fecha</th>
                            <th scope="col" class="text-end">Acciones</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $fichas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ficha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($ficha->num_ficha ?: $ficha->id); ?></td>
                            <td><?php echo e($ficha->num_crt ?: 'Sin especificar'); ?></td>
                            <td><?php echo e($ficha->cliente_nombre ?: $ficha->cliente?->nombre ?: 'Sin especificar'); ?></td>
                            <td>
                                <div><?php echo e($ficha->clienteInternacional?->nombre ?: 'Sin especificar'); ?></div>
                                <?php if($ficha->clienteInternacional): ?>
                                <small class="text-secondary">
                                    <?php echo e($ficha->tipo_operacion === 'importacion' ? 'Exportador' : ($ficha->tipo_operacion === 'exportacion' ? 'Importador' : 'Rol sin definir')); ?>

                                    ·
                                    <?php echo e($ficha->clienteInternacional->origen === 'brasil' ? 'Brasil' : ($ficha->clienteInternacional->origen === 'argentina' ? 'Argentina' : 'País sin especificar')); ?>

                                </small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($ficha->tipo_operacion === 'importacion'): ?>
                                <span class="badge text-bg-primary">Importación</span>
                                <?php elseif($ficha->tipo_operacion === 'exportacion'): ?>
                                <span class="badge text-bg-success">Exportación</span>
                                <?php else: ?>
                                <span class="badge text-bg-secondary">Sin especificar</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($ficha->transportista?->nombre ?: 'Sin asignar'); ?></td>
                            <td>
                                <?php switch($ficha->estado):
                                case ('iniciada'): ?>
                                <span class="badge text-bg-secondary">Iniciada</span>
                                <?php break; ?>
                                <?php case ('en_curso'): ?>
                                <span class="badge text-bg-warning">En curso</span>
                                <?php break; ?>
                                <?php case ('en_frontera'): ?>
                                <span class="badge text-bg-info">En frontera</span>
                                <?php break; ?>
                                <?php case ('entregada'): ?>
                                <span class="badge text-bg-success">Entregada</span>
                                <?php break; ?>
                                <?php default: ?>
                                <span class="badge text-bg-secondary">
                                    <?php echo e(ucfirst(str_replace('_', ' ', $ficha->estado))); ?>

                                </span>
                                <?php endswitch; ?>
                            </td>
                            <td><?php echo e($ficha->created_at?->format('d/m/Y') ?: 'Sin fecha'); ?></td>
                            <td class="text-end">
                                <a href="<?php echo e(route('panel.fichas.show', $ficha)); ?>"
                                    class="btn btn-sm btn-outline-dark">Ver</a>
                                <a href="<?php echo e(route('panel.fichas.edit', $ficha)); ?>"
                                    class="btn btn-sm btn-outline-warning">Editar</a>
                                <form method="POST" action="<?php echo e(route('panel.fichas.destroy', $ficha)); ?>"
                                    class="d-inline formulario-anular-ficha"
                                    data-numero-ficha="<?php echo e($ficha->num_ficha ?: $ficha->id); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger">Anular</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="text-center text-secondary py-5">
                                <i class="bi bi-file-earmark-text fs-1 d-block mb-2"></i>
                                No hay fichas activas que coincidan con la búsqueda.
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="card-footer bg-white text-secondary">
                Fichas activas encontradas: <?php echo e($fichas->count()); ?>

            </div>
        </section>
    </main>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Fefog\Desktop\Proyecto-Final\Translogistica\resources\views\panel\fichas\index.blade.php ENDPATH**/ ?>