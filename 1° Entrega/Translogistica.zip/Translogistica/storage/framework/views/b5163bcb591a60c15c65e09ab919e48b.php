<?php $__env->startSection('title', 'Editar cliente | Translogística'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-vh-100 bg-light">
    <?php if (isset($component)) { $__componentOriginalbe062454937ca58204f074f7f20cd3ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbe062454937ca58204f074f7f20cd3ac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.panel-navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('panel-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbe062454937ca58204f074f7f20cd3ac)): ?>
<?php $attributes = $__attributesOriginalbe062454937ca58204f074f7f20cd3ac; ?>
<?php unset($__attributesOriginalbe062454937ca58204f074f7f20cd3ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbe062454937ca58204f074f7f20cd3ac)): ?>
<?php $component = $__componentOriginalbe062454937ca58204f074f7f20cd3ac; ?>
<?php unset($__componentOriginalbe062454937ca58204f074f7f20cd3ac); ?>
<?php endif; ?>

    <main class="container py-5">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-8">
                <div class="mb-4">
                    <a href="<?php echo e(route('panel.clientes.index')); ?>" class="text-decoration-none">
                        <i class="bi bi-arrow-left me-1"></i>
                        Volver a clientes
                    </a>
                </div>

                <section class="card border-0 shadow-sm">
                    <div class="card-header bg-dark text-white py-3">
                        <h1 class="h4 mb-0">Editar cliente</h1>
                    </div>

                    <div class="card-body p-4 p-md-5">
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger" role="alert">
                            Revisá los campos señalados antes de continuar.
                        </div>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route('panel.clientes.update', $cliente)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="row g-4">
                                <div class="col-12">
                                    <label for="nombre" class="form-label fw-semibold">Nombre del cliente</label>
                                    <input type="text" id="nombre" name="nombre"
                                        value="<?php echo e(old('nombre', $cliente->nombre)); ?>"
                                        class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        maxlength="255" required>
                                    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-12 col-md-6">
                                    <label for="origen" class="form-label fw-semibold">País de origen</label>
                                    <select id="origen" name="origen"
                                        class="form-select <?php $__errorArgs = ['origen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="" disabled <?php if(!old('origen', $cliente->origen)): echo 'selected'; endif; ?>>
                                            Seleccionar
                                        </option>
                                        <option value="local" <?php if(old('origen', $cliente->origen) === 'local'): echo 'selected'; endif; ?>>
                                            Uruguay
                                        </option>
                                        <option value="brasil" <?php if(old('origen', $cliente->origen) === 'brasil'): echo 'selected'; endif; ?>>
                                            Brasil
                                        </option>
                                        <option value="argentina" <?php if(old('origen', $cliente->origen) === 'argentina'): echo 'selected'; endif; ?>>
                                            Argentina
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['origen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-12 col-md-6">
                                    <label for="telefono" class="form-label fw-semibold">
                                        Teléfono <span class="text-secondary fw-normal">(opcional)</span>
                                    </label>
                                    <input type="tel" id="telefono" name="telefono"
                                        value="<?php echo e(old('telefono', $cliente->telefono)); ?>"
                                        class="form-control <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Ej.: +55 11 99999-9999"
                                        autocomplete="tel" maxlength="50">
                                    <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <div class="form-text">Puede ser un teléfono fijo o celular.</div>
                                </div>

                                <div class="col-12 col-md-6">
                                    <label for="contacto_nombre" class="form-label fw-semibold">
                                        Nombre de contacto <span class="text-secondary fw-normal">(opcional)</span>
                                    </label>
                                    <input type="text" id="contacto_nombre" name="contacto_nombre"
                                        value="<?php echo e(old('contacto_nombre', $cliente->contacto_nombre)); ?>"
                                        class="form-control <?php $__errorArgs = ['contacto_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        maxlength="255">
                                    <?php $__errorArgs = ['contacto_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-12 col-md-6">
                                    <label for="contacto_email" class="form-label fw-semibold">
                                        Email de contacto <span class="text-secondary fw-normal">(opcional)</span>
                                    </label>
                                    <input type="email" id="contacto_email" name="contacto_email"
                                        value="<?php echo e(old('contacto_email', $cliente->contacto_email)); ?>"
                                        class="form-control <?php $__errorArgs = ['contacto_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        maxlength="255">
                                    <?php $__errorArgs = ['contacto_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-12" id="datos-nacionales">
                                    <label for="ruc_rut" class="form-label fw-semibold">
                                        RUC / RUT <span class="text-secondary fw-normal">(opcional)</span>
                                    </label>
                                    <input type="text" id="ruc_rut" name="ruc_rut"
                                        value="<?php echo e(old('ruc_rut', $cliente->ruc_rut)); ?>"
                                        class="form-control <?php $__errorArgs = ['ruc_rut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        maxlength="50">
                                    <?php $__errorArgs = ['ruc_rut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-12" id="datos-internacionales">
                                    <label for="despachante" class="form-label fw-semibold">
                                        Despachante <span class="text-secondary fw-normal">(opcional)</span>
                                    </label>
                                    <input type="text" id="despachante" name="despachante"
                                        value="<?php echo e(old('despachante', $cliente->despachante)); ?>"
                                        class="form-control <?php $__errorArgs = ['despachante'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        maxlength="255">
                                    <?php $__errorArgs = ['despachante'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-12">
                                    <label for="direccion" class="form-label fw-semibold">
                                        Dirección <span class="text-secondary fw-normal">(opcional)</span>
                                    </label>
                                    <input type="text" id="direccion" name="direccion"
                                        value="<?php echo e(old('direccion', $cliente->direccion)); ?>"
                                        class="form-control <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Calle, número y ciudad" maxlength="255">
                                    <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-12" id="datos-acceso">
                                    <hr>
                                    <h2 class="h5 fw-bold mb-3">Datos de acceso</h2>
                                    <p class="text-secondary mb-3">
                                        Los clientes de Uruguay, Brasil y Argentina pueden ingresar
                                        al portal con su usuario y contraseña.
                                    </p>

                                    <div class="row g-4">
                                        <div class="col-12">
                                            <label for="usuario" class="form-label fw-semibold">
                                                Usuario
                                            </label>
                                            <input type="text" id="usuario" name="usuario"
                                                value="<?php echo e(old('usuario', $cliente->usuario)); ?>"
                                                class="form-control <?php $__errorArgs = ['usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                autocomplete="username"
                                                minlength="3" maxlength="255" required>
                                            <?php $__errorArgs = ['usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-12">
                                            <?php if(blank($cliente->password)): ?>
                                            <h3 class="h5 fw-bold">Establecer contraseña</h3>
                                            <p class="text-secondary mb-0">
                                                Este cliente todavía no tiene una contraseña.
                                                Debés establecer una para habilitar su acceso al portal.
                                            </p>
                                            <?php else: ?>
                                            <h3 class="h5 fw-bold">Cambiar contraseña</h3>
                                            <p class="text-secondary mb-0">
                                                Dejá estos campos vacíos si no querés modificar
                                                la contraseña actual.
                                            </p>
                                            <?php endif; ?>
                                        </div>

                                        <div class="col-12 col-md-6">
                                            <label for="password" class="form-label fw-semibold">
                                                <?php echo e(blank($cliente->password) ? 'Contraseña' : 'Nueva contraseña'); ?>

                                            </label>
                                            <input type="password" id="password" name="password"
                                                class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                autocomplete="new-password"
                                                minlength="8" maxlength="255"
                                                <?php if(blank($cliente->password)): ?> required <?php endif; ?>>
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <div class="form-text">
                                                Debe contener al menos 8 caracteres.
                                            </div>
                                        </div>

                                        <div class="col-12 col-md-6">
                                            <label for="password_confirmation" class="form-label fw-semibold">
                                                Confirmar contraseña
                                            </label>
                                            <input type="password"
                                                id="password_confirmation"
                                                name="password_confirmation"
                                                class="form-control"
                                                autocomplete="new-password"
                                                minlength="8" maxlength="255"
                                                <?php if(blank($cliente->password)): ?> required <?php endif; ?>>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12 d-flex flex-column flex-sm-row justify-content-end gap-2">
                                    <a href="<?php echo e(route('panel.clientes.show', $cliente)); ?>"
                                        class="btn btn-outline-secondary">
                                        Cancelar
                                    </a>
                                    <button type="submit" class="btn btn-warning fw-bold">
                                        <i class="bi bi-check-circle-fill me-2"></i>
                                        Guardar cambios
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
            </div>
        </div>
    </main>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const origen = document.getElementById('origen');
        const nacionales = document.getElementById('datos-nacionales');
        const internacionales = document.getElementById('datos-internacionales');

        function actualizarCampos() {
            const esNacional = origen.value === 'local';
            const esInternacional = origen.value === 'brasil' ||
                origen.value === 'argentina';

            nacionales.hidden = !esNacional;
            internacionales.hidden = !esInternacional;

            nacionales.querySelectorAll('input').forEach(function(campo) {
                campo.disabled = !esNacional;
            });

            internacionales.querySelectorAll('input').forEach(function(campo) {
                campo.disabled = !esInternacional;
            });
        }

        origen.addEventListener('change', actualizarCampos);
        actualizarCampos();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Fefog\Desktop\Proyecto-Final\Translogistica\resources\views\panel\clientes\edit.blade.php ENDPATH**/ ?>