<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>
        <?php echo $__env->yieldContent('title', 'Translogística'); ?>
    </title>

    <link rel="icon" type="image/png" href="<?php echo e(asset('images/favicon-translogistica.png')); ?>">

    <link rel="apple-touch-icon" href="<?php echo e(asset('images/favicon-translogistica.png')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>

</html>
<?php /**PATH C:\Users\Fefog\Desktop\Proyecto-Final\Translogistica\resources\views/layouts/app.blade.php ENDPATH**/ ?>