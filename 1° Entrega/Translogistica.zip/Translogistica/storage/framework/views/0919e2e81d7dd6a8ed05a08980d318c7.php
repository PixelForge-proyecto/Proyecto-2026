<?php $__env->startSection('title', 'Área del cliente | Translogística'); ?>

<?php $__env->startSection('content'); ?>
    <div class="min-vh-100 bg-light">
        <?php if (isset($component)) { $__componentOriginal19fff246197017a876e8761e85e28801 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19fff246197017a876e8761e85e28801 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cliente-navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cliente-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19fff246197017a876e8761e85e28801)): ?>
<?php $attributes = $__attributesOriginal19fff246197017a876e8761e85e28801; ?>
<?php unset($__attributesOriginal19fff246197017a876e8761e85e28801); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19fff246197017a876e8761e85e28801)): ?>
<?php $component = $__componentOriginal19fff246197017a876e8761e85e28801; ?>
<?php unset($__componentOriginal19fff246197017a876e8761e85e28801); ?>
<?php endif; ?>
        <main class="container py-5">
            <header class="mb-5">
                <h1 class="fw-bold mb-2">
                    Área del cliente
                </h1>

                <p class="text-secondary mb-0">
                    Consultá tus cargas y revisá el estado de cada operación.
                </p>
            </header>

            <div class="row g-4">
                <div class="col-12 col-lg-8">
                    <section class="card border-0 shadow-sm h-100">
                        <div class="card-body p-4">
                            <i class="bi bi-search fs-1 text-warning"></i>

                            <h2 class="h4 fw-bold mt-3 mb-3">
                                Buscar una carga
                            </h2>

                            <p class="text-secondary">
                                Ingresá el número de DUA para consultar el estado
                                de la carga.
                            </p>

                            <form method="GET" action="<?php echo e(route('cliente.cargas.buscar')); ?>">
                                <div class="row g-3 align-items-end">
                                    <div class="col-12 col-md-8">
                                        <label for="numero-dua" class="form-label fw-semibold">
                                            Número de DUA
                                        </label>

                                        <input type="text" id="numero-dua" name="dua" value="<?php echo e(old('dua')); ?>"
                                            class="form-control
                                                <?php $__errorArgs = ['dua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="Ejemplo: 123456" inputmode="numeric" maxlength="6"
                                            pattern="[0-9]{1,6}">

                                        <?php $__errorArgs = ['dua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-12 col-md-4">
                                        <button type="submit" class="btn btn-warning fw-bold w-100">
                                            <i class="bi bi-search me-2"></i>
                                            Buscar carga
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </section>
                </div>

                <div class="col-12 col-lg-4">
                    <section class="card border-0 shadow-sm h-100">
                        <div class="card-body p-4 d-flex flex-column">
                            <i class="bi bi-truck fs-1 text-warning"></i>

                            <h2 class="h4 fw-bold mt-3 mb-3">
                                Mis cargas
                            </h2>

                            <p class="text-secondary">
                                Revisá todas las operaciones asociadas a tu cuenta
                                y consultá su seguimiento.
                            </p>

                            <a href="<?php echo e(route('cliente.cargas.index')); ?>" class="btn btn-dark fw-semibold mt-auto">
                                Ver mis cargas
                            </a>
                        </div>
                    </section>
                </div>
            </div>
        </main>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Fefog\Desktop\Proyecto-Final\Translogistica\resources\views\cliente\inicio.blade.php ENDPATH**/ ?>