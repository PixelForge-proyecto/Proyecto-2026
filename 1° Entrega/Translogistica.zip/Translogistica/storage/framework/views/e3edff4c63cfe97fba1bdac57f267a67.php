

<?php $__env->startSection('title', 'Despachantes locales | Translogística'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-vh-100 bg-light">
    <?php if (isset($component)) { $__componentOriginalbe062454937ca58204f074f7f20cd3ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbe062454937ca58204f074f7f20cd3ac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.panel-navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('panel-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbe062454937ca58204f074f7f20cd3ac)): ?>
<?php $attributes = $__attributesOriginalbe062454937ca58204f074f7f20cd3ac; ?>
<?php unset($__attributesOriginalbe062454937ca58204f074f7f20cd3ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbe062454937ca58204f074f7f20cd3ac)): ?>
<?php $component = $__componentOriginalbe062454937ca58204f074f7f20cd3ac; ?>
<?php unset($__componentOriginalbe062454937ca58204f074f7f20cd3ac); ?>
<?php endif; ?>

    <main class="container py-5">
        <?php if(session('status')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('status')); ?>


            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
        </div>
        <?php endif; ?>

        <div
            class="d-flex flex-column flex-md-row
                    justify-content-between align-items-md-center
                    gap-3 mb-4">
            <div>
                <h1 class="fw-bold mb-1">
                    Despachantes locales
                </h1>

                <p class="text-secondary mb-0">
                    Consulta y administración de los despachantes
                    de aduana locales de Uruguay.
                </p>
            </div>

            <a href="<?php echo e(route('panel.despachantes.create')); ?>" class="btn btn-warning fw-bold">
                <i class="bi bi-person-vcard me-2"></i>
                Nuevo despachante
            </a>
        </div>

        <section class="card border-0 shadow-sm mb-4">
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('panel.despachantes.index')); ?>">
                    <div class="row g-3 align-items-end">
                        <div class="col-12 col-lg-8">
                            <label for="buscar-despachante" class="form-label fw-semibold">
                                Buscar despachante local
                            </label>

                            <input type="search" id="buscar-despachante" name="buscar"
                                value="<?php echo e(request('buscar')); ?>" class="form-control"
                                placeholder="Nombre, correo electrónico, contacto o gestor">
                        </div>

                        <div class="col-12 col-lg-4">
                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-dark flex-grow-1">
                                    <i class="bi bi-search me-2"></i>
                                    Buscar
                                </button>

                                <?php if(request()->filled('buscar')): ?>
                                <a href="<?php echo e(route('panel.despachantes.index')); ?>"
                                    class="btn btn-outline-secondary" title="Limpiar búsqueda"
                                    aria-label="Limpiar búsqueda">
                                    <i class="bi bi-x-lg"></i>
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </section>

        <section class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h2 class="h5 fw-bold mb-0">
                    Despachantes registrados
                </h2>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th scope="col">Nombre</th>
                            <th scope="col">Correo electrónico</th>
                            <th scope="col">Contacto</th>
                            <th scope="col">Gestor</th>
                            <th scope="col" class="text-end">
                                Acciones
                            </th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $despachantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $despachante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <?php echo e($despachante->nombre); ?>

                            </td>

                            <td>
                                <?php echo e($despachante->email ?: 'Sin especificar'); ?>

                            </td>

                            <td>
                                <?php echo e($despachante->contacto ?: 'Sin especificar'); ?>

                            </td>

                            <td>
                                <?php echo e($despachante->gestor ?: 'Sin especificar'); ?>

                            </td>

                            <td class="text-end">
                                <a href="<?php echo e(route('panel.despachantes.show', $despachante)); ?>"
                                    class="btn btn-sm btn-outline-dark">
                                    Ver
                                </a>

                                <a href="<?php echo e(route('panel.despachantes.edit', $despachante)); ?>"
                                    class="btn btn-sm btn-outline-warning">
                                    Editar
                                </a>

                                <form method="POST"
                                    action="<?php echo e(route('panel.despachantes.destroy', $despachante)); ?>"
                                    class="d-inline formulario-baja-despachante"
                                    data-nombre-despachante="<?php echo e($despachante->nombre); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button type="submit" class="btn btn-sm btn-outline-danger">
                                        Dar de baja
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center text-secondary py-5">
                                <i class="bi bi-person-vcard fs-1 d-block mb-2"></i>

                                No hay despachantes locales activos que
                                coincidan con la búsqueda.
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="card-footer bg-white text-secondary">
                Despachantes locales activos encontrados:
                <?php echo e($despachantes->count()); ?>

            </div>
        </section>
    </main>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Fefog\Desktop\Proyecto-Final\Translogistica\resources\views\panel\despachantes\index.blade.php ENDPATH**/ ?>