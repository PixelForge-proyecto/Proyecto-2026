CREATE DATABASE IF NOT EXISTS `translogistica`
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE `translogistica`;

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `seguimientos`;
DROP TABLE IF EXISTS `notificaciones`;
DROP TABLE IF EXISTS `fichas`;
DROP TABLE IF EXISTS `usuarios_internos`;
DROP TABLE IF EXISTS `transportistas`;
DROP TABLE IF EXISTS `clientes`;

CREATE TABLE `clientes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `origen` enum('local', 'brasil', 'argentina') NOT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `usuario` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL COMMENT 'Solo hash',
  `estado` enum('activo', 'inactivo') NOT NULL DEFAULT 'activo',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`),
  KEY `idx_clientes_nombre` (`nombre`),
  KEY `idx_clientes_origen` (`origen`)
) ENGINE = InnoDB AUTO_INCREMENT = 3 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

CREATE TABLE `transportistas` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contacto` varchar(255) DEFAULT NULL,
  `estado` enum('activo', 'inactivo') NOT NULL DEFAULT 'activo',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_transportistas_nombre` (`nombre`),
  KEY `idx_transportistas_email` (`email`)
) ENGINE = InnoDB AUTO_INCREMENT = 4 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

CREATE TABLE `usuarios_internos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `usuario` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL COMMENT 'Solo hash',
  `rol` enum('administrativo', 'operativo', 'vendedor') NOT NULL,
  `estado` enum('activo', 'inactivo') NOT NULL DEFAULT 'activo',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`)
) ENGINE = InnoDB AUTO_INCREMENT = 2 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

CREATE TABLE `fichas` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `num_ficha` varchar(50) DEFAULT NULL COMMENT 'Interno; no se muestra al cliente',
  `tipo_operacion` enum('importacion', 'exportacion') NOT NULL,
  `cliente_id` bigint unsigned NOT NULL,
  `transportista_id` bigint unsigned DEFAULT NULL,
  `vendedor_id` bigint unsigned DEFAULT NULL,
  `estado` enum(
    'iniciada',
    'en_curso',
    'en_frontera',
    'entregada',
    'anulada'
  ) NOT NULL DEFAULT 'iniciada',
  `num_crt` varchar(255) DEFAULT NULL,
  `cliente_nombre` varchar(255) DEFAULT NULL,
  `cliente_contacto` varchar(255) DEFAULT NULL,
  `cliente_telefono` varchar(50) DEFAULT NULL,
  `cliente_ruc_rut` varchar(50) DEFAULT NULL,
  `nombre_exportador` varchar(255) DEFAULT NULL,
  `contacto_exportador_nombre` varchar(255) DEFAULT NULL,
  `contacto_exportador_email` varchar(255) DEFAULT NULL,
  `telefono_exportador` varchar(50) DEFAULT NULL,
  `despachante_exportador` varchar(255) DEFAULT NULL,
  `mercaderia` varchar(255) DEFAULT NULL,
  `tipo_carga` enum('consolidada', 'completa') DEFAULT NULL,
  `peso_bruto` decimal(10, 2) DEFAULT NULL COMMENT 'kg',
  `volumen` decimal(10, 2) DEFAULT NULL COMMENT 'm3',
  `tipo_bulto` varchar(255) DEFAULT NULL,
  `cantidad_bultos` int unsigned DEFAULT NULL,
  `num_factura` varchar(255) DEFAULT NULL,
  `ciudad_carga` varchar(255) DEFAULT NULL,
  `frontera` varchar(255) DEFAULT NULL,
  `coleta` varchar(255) DEFAULT NULL,
  `ciudad_descarga` varchar(255) DEFAULT NULL,
  `direccion_descarga` varchar(255) DEFAULT NULL,
  `telefono_descarga` varchar(50) DEFAULT NULL,
  `contacto_descarga` varchar(255) DEFAULT NULL,
  `email_descarga` varchar(255) DEFAULT NULL,
  `despachante_local_nombre` varchar(255) DEFAULT NULL,
  `despachante_local_email` varchar(255) DEFAULT NULL,
  `despachante_local_telefono` varchar(50) DEFAULT NULL,
  `despachante_local_direccion` varchar(255) DEFAULT NULL,
  `despachante_local_gestor` varchar(255) DEFAULT NULL,
  `despachante_local_gestor_telefono` varchar(50) DEFAULT NULL,
  `despachante_local_contacto` varchar(255) DEFAULT NULL,
  `dua` varchar(6) DEFAULT NULL COMMENT 'Máx. 6 dígitos',
  `hecha_por` varchar(255) DEFAULT NULL,
  `fecha_comercial` date DEFAULT NULL,
  `puesta_fob` decimal(12, 2) DEFAULT NULL,
  `flete_internacional` decimal(12, 2) DEFAULT NULL,
  `flete_nacional` decimal(12, 2) DEFAULT NULL,
  `ad_valorem_porcentaje` decimal(5, 2) DEFAULT NULL,
  `ad_valorem` decimal(12, 2) DEFAULT NULL,
  `despacho_brasil` decimal(12, 2) DEFAULT NULL,
  `total_comercial` decimal(12, 2) DEFAULT NULL,
  `fob_usd` decimal(12, 2) DEFAULT NULL,
  `proforma` varchar(255) DEFAULT NULL,
  `factura_definitiva` varchar(255) DEFAULT NULL,
  `cantidad_camiones` int unsigned DEFAULT NULL,
  `flete_por_camion` varchar(255) DEFAULT NULL,
  `observaciones_comerciales` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `num_ficha` (`num_ficha`),
  UNIQUE KEY `num_crt` (`num_crt`),
  KEY `cliente_id` (`cliente_id`),
  KEY `transportista_id` (`transportista_id`),
  KEY `vendedor_id` (`vendedor_id`),
  KEY `idx_fichas_dua` (`dua`),
  KEY `idx_fichas_estado` (`estado`),
  KEY `idx_fichas_created` (`created_at`),
  CONSTRAINT `fichas_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`),
  CONSTRAINT `fichas_ibfk_2` FOREIGN KEY (`transportista_id`) REFERENCES `transportistas` (`id`),
  CONSTRAINT `fichas_ibfk_3` FOREIGN KEY (`vendedor_id`) REFERENCES `usuarios_internos` (`id`),
  CONSTRAINT `chk_fichas_dua` CHECK (
    (
      (`dua` is null)
      or regexp_like(`dua`, _utf8mb4 '^[0-9]{1,6}$')
    )
  )
) ENGINE = InnoDB AUTO_INCREMENT = 2 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

CREATE TABLE `notificaciones` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ficha_id` bigint unsigned NOT NULL,
  `tipo` varchar(255) NOT NULL,
  `mensaje` text NOT NULL,
  `leida` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ficha_id` (`ficha_id`),
  CONSTRAINT `notificaciones_ibfk_1` FOREIGN KEY (`ficha_id`) REFERENCES `fichas` (`id`) ON DELETE RESTRICT
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

CREATE TABLE `seguimientos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ficha_id` bigint unsigned NOT NULL,
  `etapa` enum(
    'carga',
    'deposito',
    'frontera',
    'aduana_internacional',
    'aduana_nacional',
    'liberacion',
    'entrega'
  ) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `canal_aduanero` enum('verde', 'naranja', 'rojo') DEFAULT NULL,
  `observacion` text,
  `notificar_cliente` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_seguimientos_ficha_fecha` (`ficha_id`, `fecha`),
  CONSTRAINT `seguimientos_ibfk_1` FOREIGN KEY (`ficha_id`) REFERENCES `fichas` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_seguimiento_con_datos` CHECK (
    (
      (`etapa` is not null)
      or (`fecha` is not null)
      or (`observacion` is not null)
    )
  ),
  CONSTRAINT `chk_seguimiento_etapa_fecha` CHECK (
    (
      (
        (`etapa` is null)
        and (`fecha` is null)
      )
      or (
        (`etapa` is not null)
        and (`fecha` is not null)
      )
    )
  ),
  CONSTRAINT `chk_seguimientos_canal` CHECK (
    (
      (`canal_aduanero` is null)
      or (
        `etapa` in (
          _latin1 'aduana_internacional',
          _latin1 'aduana_nacional'
        )
      )
    )
  )
) ENGINE = InnoDB AUTO_INCREMENT = 13 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

INSERT INTO
  `clientes`
VALUES
  (
    1,
    'Cliente de prueba',
    'local',
    'Montevideo',
    'cliente.prueba',
    '$2y$12$YdkuONbBQ5Fuw.rkB8NSaO7L4k7Mc4syHC5Nb/D1qXAlViTvFdK9S',
    'activo',
    '2026-10-16 00:34:33',
    '2026-10-18 21:01:21'
  ),
  (
    2,
    'Cliente de prueba',
    'brasil',
    'Floripa, Brasil',
    'cliente',
    '$2y$12$OT628fsaIHbxEdOAyxUoTeC5tX6Zicwxh3Ky9HYuV94ABP/VCqtMO',
    'inactivo',
    '2026-10-17 00:12:44',
    '2026-10-18 20:49:39'
  );

INSERT INTO
  `transportistas`
VALUES
  (
    1,
    'Transportes de prueba',
    'transporte@prueba.com',
    '099 123 454',
    'inactivo',
    '2026-10-18 20:30:16',
    '2026-10-18 20:36:49'
  ),
  (
    2,
    'Transportes1',
    'transportes1@prueba.com',
    '098 674 299',
    'inactivo',
    '2026-10-18 20:34:00',
    '2026-10-18 20:36:53'
  ),
  (
    3,
    'Transportista 1',
    'Transportista@gmail.com',
    '098 765 433',
    'activo',
    '2026-10-18 21:01:56',
    '2026-10-19 20:05:57'
  );

INSERT INTO
  `usuarios_internos`
VALUES
  (
    1,
    'Administrador interno',
    'interno',
    '$2y$12$X.krhQLE2JjOFnZ5IoMTN.QCtr3f5XgZ4bv.hjOpViifGWj8/jIYy',
    'administrativo',
    'activo',
    '2026-10-16 23:40:45',
    '2026-10-16 23:40:45'
  );

INSERT INTO
  `fichas`
VALUES
  (
    1,
    'F-0001',
    'importacion',
    1,
    3,
    1,
    'entregada',
    'CRT-0001',
    'Cliente de prueba',
    'Federico',
    '099123456',
    '123456789012',
    'Exportadora Brasil Ltda.',
    'María Silva',
    'maria@exportadora.com',
    '551199999999',
    'Despachante Brasil',
    'Productos veterinarios y farmacéuticos',
    'completa',
    1300.00,
    8.50,
    'Cajas',
    25,
    'FAC-0001',
    'São Paulo',
    'Rivera',
    'Depósito central',
    'Montevideo',
    'Ruta 5 km 15',
    '29001234',
    'Juan Pérez',
    'deposito@cliente.com',
    'Despachante Local S.A.',
    'contacto@despachantelocal.com',
    '29005678',
    'Av. Uruguay 1234',
    'Carlos Rodríguez',
    '098765432',
    'Oficina de operaciones',
    '123456',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-10-18 21:04:58',
    '2026-10-22 01:54:04'
  );

INSERT INTO
  `seguimientos`
VALUES
  (
    2,
    1,
    'frontera',
    '2026-10-22',
    NULL,
    'El vehículo llegó a frontera',
    1,
    '2026-10-20 13:10:18',
    '2026-10-22 01:27:58'
  ),
  (
    3,
    1,
    'carga',
    '2026-10-20',
    NULL,
    'La mercadería fue cargada correctamente',
    1,
    '2026-10-21 23:04:23',
    '2026-10-22 01:27:32'
  ),
  (
    4,
    1,
    'aduana_internacional',
    '2026-10-20',
    'verde',
    NULL,
    0,
    '2026-10-21 23:08:17',
    '2026-10-21 23:08:17'
  ),
  (
    5,
    1,
    'aduana_nacional',
    '2026-10-20',
    'verde',
    NULL,
    0,
    '2026-10-21 23:08:31',
    '2026-10-21 23:08:31'
  ),
  (
    6,
    1,
    'liberacion',
    '2026-10-22',
    NULL,
    NULL,
    0,
    '2026-10-21 23:12:22',
    '2026-10-21 23:12:22'
  ),
  (
    7,
    1,
    'aduana_internacional',
    '2026-10-22',
    NULL,
    NULL,
    0,
    '2026-10-21 23:12:39',
    '2026-10-21 23:12:39'
  ),
  (
    8,
    1,
    'aduana_nacional',
    '2026-10-22',
    NULL,
    NULL,
    0,
    '2026-10-21 23:12:54',
    '2026-10-21 23:12:54'
  ),
  (
    9,
    1,
    'liberacion',
    '2026-10-22',
    NULL,
    NULL,
    0,
    '2026-10-21 23:13:15',
    '2026-10-21 23:13:46'
  ),
  (
    10,
    1,
    'entrega',
    '2026-10-23',
    NULL,
    NULL,
    0,
    '2026-10-21 23:14:04',
    '2026-10-21 23:14:04'
  ),
  (
    11,
    1,
    'aduana_internacional',
    '2026-10-22',
    'verde',
    NULL,
    0,
    '2026-10-21 23:20:17',
    '2026-10-21 23:20:17'
  ),
  (
    12,
    1,
    'aduana_nacional',
    '2026-10-22',
    'verde',
    NULL,
    0,
    '2026-10-21 23:20:35',
    '2026-10-21 23:20:35'
  );

SET FOREIGN_KEY_CHECKS = 1;

DELIMITER $$

DROP TRIGGER IF EXISTS `trg_clientes_usuario_bi`$$

CREATE TRIGGER `trg_clientes_usuario_bi` BEFORE INSERT ON `clientes` FOR EACH ROW BEGIN
 IF EXISTS (SELECT 1 FROM usuarios_internos WHERE usuario = NEW.usuario) THEN
 SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El usuario ya existe como usuario interno';
 END IF;
 END$$

DELIMITER ;

DELIMITER $$

DROP TRIGGER IF EXISTS `trg_clientes_usuario_bu`$$

CREATE TRIGGER `trg_clientes_usuario_bu` BEFORE UPDATE ON `clientes` FOR EACH ROW BEGIN
 IF NEW.usuario <> OLD.usuario
 AND EXISTS (SELECT 1 FROM usuarios_internos WHERE usuario = NEW.usuario) THEN
 SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El usuario ya existe como usuario interno';
 END IF;
 END$$

DELIMITER ;

DELIMITER $$

DROP TRIGGER IF EXISTS `trg_internos_usuario_bi`$$

CREATE TRIGGER `trg_internos_usuario_bi` BEFORE INSERT ON `usuarios_internos` FOR EACH ROW BEGIN
 IF EXISTS (SELECT 1 FROM clientes WHERE usuario = NEW.usuario) THEN
 SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El usuario ya existe como cliente';
 END IF;
 END$$

DELIMITER ;

DELIMITER $$

DROP TRIGGER IF EXISTS `trg_internos_usuario_bu`$$

CREATE TRIGGER `trg_internos_usuario_bu` BEFORE UPDATE ON `usuarios_internos` FOR EACH ROW BEGIN
 IF NEW.usuario <> OLD.usuario
 AND EXISTS (SELECT 1 FROM clientes WHERE usuario = NEW.usuario) THEN
 SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El usuario ya existe como cliente';
 END IF;
 END$$

DELIMITER ;
